const { connection, uploadTemplatePic, uploadImg, jwtverify, sendpushNotify, escapString, subscriptionExpire, parseCustomDate } = require("../modules/modules");
const { body, validationResult } = require("express-validator")
const { sqlQuery } = require('../modules/sql');
const CryptoJS = require('crypto-js')
const jwt = require("jsonwebtoken")
const express = require('express');
const response = require("node-router/lib/response");
const router = express.Router()
require('dotenv').config()
const Razorpay = require("razorpay");
const isBase64 = value => /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{4})$/.test(value);
const nodemailer = require('nodemailer');
var randomToken = require('random-token');
let db = connection;
let sqlquery;
const instance = new Razorpay({
    key_id: process.env.RAZOR_PAY_KEY_ID,
    key_secret: process.env.RAZOR_PAY_KEY_SECRET,
});
// Set up a global error handler for uncaught exceptions
process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
    // Perform cleanup or other necessary actions
    process.exit(1); // Exit the process with a non-zero status code
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
    // Perform cleanup or other necessary actions
    // Note: The process may not exit immediately after handling an unhandled rejection
});


router.get('/get-smm-iyyyy', (req, res) => {
    //select year type integer like 2022,2023
    sqlquery = "select * from int_year";
    db.query(sqlquery, (err, result, fields) => {
        if (err) {

            res.send({ "statusCode": 500, 'status': "Internal Server Error" });
            return;
        }

        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let year = result;
            //select month type string like Jan,Feb
            sqlquery = "select * from str_month";
            db.query(sqlquery, (err, result, fields) => {
                if (err) throw err;
                if (result.length == 0) {
                    res.send({ "status": 400 })
                } else {
                    let month = result
                    res.send({ "statusCode": 200, year, month });
                }
            })
        }
    })
})

router.get('/get-YM', async (req, res) => {
    try {
        let sqlquery = 'select month from int_str_month';
        const result1 = await db.promise().query(sqlquery);
        let ISmonth = result1[0];

        sqlquery = 'select year from int_str_year';
        const result2 = await db.promise().query(sqlquery);
        let ISyear = result2[0];

        sqlquery = 'select year from int_year_master';
        const result3 = await db.promise().query(sqlquery);
        let Iyear = result3[0];

        sqlquery = 'select month from str_month';
        const result4 = await db.promise().query(sqlquery);
        let Smonth = result4[0];

        res.send({ 'status': 200, ISmonth, Smonth, ISyear, Iyear });
    } catch (error) {
        console.error(error);
        res.status(500).send({ 'status': 500, 'error': 'Internal Server Error' });
    }
});


router.get('/get-course-name', (req, res) => {
    //select year type integer string like 1 Years,2 Years

    try {
        sqlquery = "select * from courses";
        sqlSpeclizaion = "select * from specialization";
        db.query(sqlquery, (err, result, fields) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
            }
            if (result.length == 0) {
                res.send({ "status": 400 })
            } else {

                // res.send({ "statusCode": 200, course });
                db.query(sqlSpeclizaion, (err, result1, fields) => {
                    if (err) {
                        console.error(err);
                        return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                    }
                    if (result1.length == 0) {
                        res.send({ "status": 400 })
                    } else {
                        let course = result;
                        let speci = result1;
                        res.send({ "statusCode": 200, course, speci });
                    }
                })
            }
        })
    } catch (error) {
        console.error(error);
        res.status(500).send({ 'status': 500, 'error': 'Internal Server Error' });
    }
})

// router.get('/get-course-name', (req, res) => {
//     //select year type integer string like 1 Years,2 Years

//     try {
//         sqlquery = "select * from courses";
//         sqlSpeclizaion = "select * from specialization";
//         db.query(sqlquery, (err, result, fields) => {
//             if (err) {
//                 console.error(err);
//                 return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
//             }
//             if (result.length == 0) {
//                 res.send({ "status": 400 })
//             } else {
//                 let course = result
//                 res.send({ "statusCode": 200, course });
//             }
//         })
//     } catch (error) {
//         console.error(error);
//         res.status(500).send({ 'status': 500, 'error': 'Internal Server Error' });
//     }
// })

//register using google login................................................
router.post('/register-google-login', (req, res) => {
    let pic = req.body.picture
    // let obj = escapString(req.body);
    let obj = req.body;
    //Checking email is exist or not............................................
    sqlquery = `select token,email from user where email ='${obj.email}'`;

    db.query(sqlquery, (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            sqlquery = `insert into user (user_name,email,profile_pic,password) values ('${obj.name}','${obj.email}','${pic}','${obj.password}')`;
            db.query(sqlquery, (err, result, fields) => {
                if (err) {
                    console.error(err);
                    return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                }
                const data = {
                    "userId": result.insertId,
                    "name": obj.name,
                    "email": obj.email,
                    "pic": pic,
                    "mode": 0
                }

                let token = jwt.sign(data, "vikashrakesh1234569898");
                //After registeration is successful update JWT in user table............................................
                sqlquery = `update user SET token ='${token}' where user_id='${result.insertId}' `
                db.query(sqlquery, (err, result1) => {
                    if (err) {
                        console.error(err);
                        return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                    }

                    let defaultCreditPoint;
                    if (result.affectedRows == 1) {

                        sqlqueryGetDefaultCreditPoint = `select package_list_id,credit_points from package_list where price=${0}`
                        db.query(sqlqueryGetDefaultCreditPoint, (err, resultGetDefaultCreditPoint, fields) => {

                            if (err) {
                                console.error(err);
                                return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                            }
                            if (resultGetDefaultCreditPoint.length == 0) {
                                res.send({ "status": 400, "message": "unable to get default credit point" })
                            }
                            else {
                                let datetime = subscriptionExpire(365 * 10)
                                sqlquery = `insert into subscription (user_id,package_id,start_date,expiration_date,status) values ('${result.insertId}','${resultGetDefaultCreditPoint[0].package_list_id}','${datetime[0]}','${datetime[1]}','Active')`;
                                db.query(sqlquery, (err, result3) => {
                                    if (err) {
                                        console.error(err);
                                        return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                                    }
                                });

                                sqlquery = `insert into credit_point (user_id,credit_point) values ('${result.insertId}','${resultGetDefaultCreditPoint[0].credit_points}')`;
                                db.query(sqlquery, (err, result) => {
                                    if (err) {
                                        console.error(err);
                                        return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                                    }

                                    res.send({
                                        "token": token,
                                        "statusCode": 200,
                                        "response": "success",
                                    })
                                })

                            }
                        })
                    }
                })

            });
        }
        else {
            res.send({ "statusCode": 200, "status": "login successful!!!", "token": result[0].token })
        }
    })
})

router.post('/register', (req, res) => {
    let pic = req.body.picture
    // let obj = escapString(req.body);
    let obj = req.body;
    //Checking email is exist or not............................................
    sqlquery = `select email from user where email ='${obj.email}'`;

    db.query(sqlquery, (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            sqlquery = `insert into user (user_name,email,profile_pic,password) values ('${obj.name}','${obj.email}','${pic}','${obj.password}')`;
            db.query(sqlquery, (err, result, fields) => {

                if (err) {
                    console.error(err);
                    return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                }

                const data = {
                    "userId": result.insertId,
                    "name": obj.name,
                    "email": obj.email,
                    "pic": pic,
                    "mode": 1
                }
                let token = jwt.sign(data, "vikashrakesh1234569898"),

                    //After registeration is successful update JWT in user table............................................
                    sqlquery = `update user SET token ='${token}' where user_id='${result.insertId}' `
                db.query(sqlquery, (err, result1) => {
                    if (err) {
                        console.error(err);
                        return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                    }

                    let defaultCreditPoint;
                    if (result.affectedRows == 1) {

                        sqlqueryGetDefaultCreditPoint = `select package_list_id,credit_points from package_list where price=${0}`
                        db.query(sqlqueryGetDefaultCreditPoint, (err, resultGetDefaultCreditPoint, fields) => {

                            if (err) {
                                console.error(err);
                                return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                            }
                            if (resultGetDefaultCreditPoint.length == 0) {
                                res.send({ "status": 400, "message": "unable to get default credit point" })
                            }
                            else {
                                let datetime = subscriptionExpire(365 * 10)
                                sqlquery = `insert into subscription (user_id,package_id,start_date,expiration_date,status) values ('${result.insertId}','${resultGetDefaultCreditPoint[0].package_list_id}','${datetime[0]}','${datetime[1]}','Active')`;
                                db.query(sqlquery, (err, result3) => {
                                    if (err) {
                                        console.error(err);
                                        return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                                    }
                                });

                                sqlquery = `insert into credit_point (user_id,credit_point) values ('${result.insertId}','${resultGetDefaultCreditPoint[0].credit_points}')`;
                                db.query(sqlquery, (err, result) => {
                                    if (err) {
                                        console.error(err);
                                        return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                                    }

                                    res.send({
                                        "token": token,
                                        "statusCode": 200,
                                        "response": "success",
                                    })
                                })

                            }
                        })
                    }
                })


            });
        }
        else {
            res.send({ "statusCode": 400, "status": "This email id has been already Exist ", "token": result[0].token })
        }
    })
})
//User login.........................................................................
router.post('/login', (req, res) => {

    //obj = escapString(req.body.inputValues);
    obj = req.body.inputValues;
    sqlquery = `select token from user where email ='${obj.email}' and password='${obj.password}' `;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400, 'status': "Invalid email or password" })
        } else {
            res.send({ "statusCode": 200, "Token": result[0].token });
        }
    })


})

router.post('/contact_us_message', (req, res) => {

    obj = escapString(req.body.inputValues);
    sqlquery = `insert into contact_us_db (name,email,subject,message) values ('${obj.name}','${obj.email}','${obj.subject}','${obj.message}')`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.affectedRows == 1) {

            const transporter = nodemailer.createTransport({
                service: 'Gmail', // Use your email service
                auth: {
                    user: 'visupater@gmail.com', // Your email
                    pass: 'gxuwysdssjnehmdw',  // Your email password
                },
            });

            const mailOptions = {
                to: `${obj.email}`,
                from: `vikashrakesh200@gmail.com`,
                subject: 'Welcome to Magic Point',
                text: `Thankyou for connecting with us.`,
            };

            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    console.error(error);
                    res.status(500).send('Error sending email');
                } else {
                    //  res.status(200).send('Email sent successfully');
                    res.send({ "statusCode": 200, "status": "Thanky for connecting with us. We contact you soon." });
                }
            });

        } else {
            res.send({ "statusCode": 400, 'status': "Message not send" })
        }
    })
})


router.post('/submit-personalDetails-resume', uploadImg.single("profilePic"), async (req, res) => {

    let obj = req.body
    const token = jwtverify(req);
    let imgPath
    if (req.file == undefined) {
        imgPath = obj.profilePic
    }
    else {
        imgPath = "http://localhost:4000/assest/profilePic/" + req.file.filename;
    }
    let result
    sqlquery = `select user_id from personal_details where user_id = ${token.userId}`;
    result = await db.promise().query(sqlquery)
    if (result[0].length == 1) {
        sqlquery = `update personal_details set  name = '${obj.name}', profile_pic = '${imgPath}', email = '${obj.email}',countryCode='${obj.countryCode}', phone = '${obj.phone}', workExperienceyear = '${obj.workExperienceyear}', workExperiencemonth = '${obj.workExperiencemonth}', resumeHeadline = '${obj.resumeHeadline}', summary = '${obj.summary}' where user_id = ${token.userId}`;
        result = await db.promise().query(sqlquery)
        if (result[0].affectedRows == 1) {
            res.send({ "statusCode": 200, 'status': "Personal details submited" })
        }
        else {
            res.send({ "statusCode": 400, 'status': "Personal details field error" })
        }
    }
    else {
        sqlquery = `insert into personal_details(user_id, name, profile_pic, email,countryCode, phone, workExperienceyear, workExperiencemonth, resumeHeadline, summary) values('${token.userId}', '${obj.name}', '${imgPath}', '${obj.email}','${obj.countryCode}', '${obj.phone}', '${obj.workExperienceyear}', '${obj.workExperiencemonth}', '${obj.resumeHeadline}', '${obj.summary}')`;
        result = await db.promise().query(sqlquery)
        if (result[0].affectedRows == 1) {
            res.send({ "statusCode": 200, 'status': "Personal details submited" })
        }
        else {
            res.send({ "statusCode": 400, 'status': "Personal details field error" })
        }
    }

})

router.post('/submit-resume', async (req, res) => {
    let obj1 = req.body
    let OB
    const token = jwtverify(req);

    if (obj1.Workexpe !== undefined) {
        const OB = obj1.Workexpe;
        let sqlquery = `SELECT user_id FROM work_experience WHERE user_id=${token.userId}`;

        db.query(sqlquery, async (err, result, fields) => {
            if (err) {
                console.error(err);
                res.send({ "statusCode": 500, 'status': "Internal Server Error" });
                return;
            }

            if (result.length >= 1) {
                sqlquery = `DELETE FROM work_experience WHERE user_id=${token.userId}`;

                db.query(sqlquery, async (err, deleteResult, fields) => {
                    if (err) {
                        console.error(err);
                        res.send({ "statusCode": 500, 'status': "Internal Server Error" });
                        return;
                    }

                    if (deleteResult.affectedRows >= 1) {
                        for (let i = 0; i < OB.length; i++) {
                            sqlquery = `INSERT INTO work_experience (user_id,company,jobTitle,currentCompany,workSinceYear,worksincemonth,workSincetoYear,worksincetomonth,workedTill,descp) VALUES ('${token.userId}','${OB[i].company}','${OB[i].jobTitle}','${OB[i].currentCompany}','${OB[i].workSinceYear}','${OB[i].worksincemonth}','${OB[i].workSincetoYear}','${OB[i].worksincetomonth}','${OB[i].workedTill}','${OB[i].descp}')`;

                            try {
                                const insertResult = await db.promise().query(sqlquery);


                                if (insertResult[0].affectedRows !== 1) {
                                    // If any insertion fails, send an error response and exit the loop
                                    res.send({ "statusCode": 400, 'status': "Work experience field error" });
                                    return;
                                }
                            } catch (insertError) {
                                console.error(insertError);
                                res.send({ "statusCode": 500, 'status': "Internal Server Error" });
                                return;
                            }
                        }

                        // If all insertions are successful, send a success response
                        res.send({ "statusCode": 200, 'status': "Work experience field added successfully!!!" });
                    }
                });
            } else {
                // If there are no existing records, insert new records
                for (let i = 0; i < OB.length; i++) {
                    sqlquery = `INSERT INTO work_experience (user_id,company,jobTitle,currentCompany,workSinceYear,worksincemonth,workSincetoYear,worksincetomonth,workedTill,descp) VALUES ('${token.userId}','${OB[i].company}','${OB[i].jobTitle}','${OB[i].currentCompany}','${OB[i].workSinceYear}','${OB[i].worksincemonth}','${OB[i].workSincetoYear}','${OB[i].worksincetomonth}','${OB[i].workedTill}','${OB[i].descp}')`;

                    try {
                        const insertResult = await db.promise().query(sqlquery);

                        if (insertResult[0].affectedRows !== 1) {
                            // If any insertion fails, send an error response and exit the loop
                            res.send({ "statusCode": 400, 'status': "Work experience field error" });
                            return;
                        }
                    } catch (insertError) {
                        console.error(insertError);
                        res.send({ "statusCode": 500, 'status': "Internal Server Error" });
                        return;
                    }
                }

                // If all insertions are successful, send a success response
                res.send({ "statusCode": 200, 'status': "Work experience field added successfully!!!" });
            }
        });
    }

    else if (obj1.Education != undefined) {
        const OB = obj1.Education;

        let sqlquery = `SELECT * FROM education WHERE user_id=${token.userId}`;

        db.query(sqlquery, async (err, result, fields) => {
            if (err) {
                console.error(err);
                res.send({ "statusCode": 500, 'status': "Internal Server Error" });
                return;
            }

            if (result.length >= 1) {
                sqlquery = `DELETE FROM education WHERE user_id=${token.userId}`;

                db.query(sqlquery, async (err, deleteResult, fields) => {
                    if (err) {
                        console.error(err);
                        res.send({ "statusCode": 500, 'status': "Internal Server Error" });
                        return;
                    }

                    if (deleteResult.affectedRows >= 1) {
                        for (let i = 0; i < OB.length; i++) {
                            //sqlquery = `INSERT INTO work_experience (user_id,company,jobTitle,currentCompany,workSinceYear,worksincemonth,workSincetoYear,worksincetomonth,workedTill,descp) VALUES ('${token.userId}','${OB[i].company}','${OB[i].jobTitle}','${OB[i].currentCompany}','${OB[i].workSinceYear}','${OB[i].worksincemonth}','${OB[i].workSincetoYear}','${OB[i].worksincetomonth}','${OB[i].workedTill}','${OB[i].descp}')`;
                            sqlquery = `INSERT INTO education (user_Id, school, courseName, specialization, date, gradingSystem, markes, courseType, descp)
VALUES ('${token.userId}', '${OB[i].school}', '${OB[i].courseName}', '${OB[i].specialization}', '${OB[i].date}', '${OB[i].gradingSystem}', '${OB[i].markes}', '${OB[i].courseType}', '${OB[i].descp}')`;

                            try {
                                const insertResult = await db.promise().query(sqlquery);


                                if (insertResult[0].affectedRows !== 1) {
                                    // If any insertion fails, send an error response and exit the loop
                                    res.send({ "statusCode": 400, 'status': "user education field insert error" });
                                    return;
                                }
                            } catch (insertError) {
                                console.error(insertError);
                                res.send({ "statusCode": 500, 'status': "Internal Server Error" });
                                return;
                            }
                        }

                        // If all insertions are successful, send a success response
                        res.send({ "statusCode": 200, 'status': "user education field insert  successfully!!!" });
                    }
                });
            } else {
                // If there are no existing records, insert new records
                for (let i = 0; i < OB.length; i++) {
                    sqlquery = `INSERT INTO education (user_Id, school, courseName, specialization, date, gradingSystem, markes, courseType, descp)
VALUES ('${token.userId}', '${OB[i].school}', '${OB[i].courseName}', '${OB[i].specialization}', '${OB[i].date}', '${OB[i].gradingSystem}', '${OB[i].markes}', '${OB[i].courseType}', '${OB[i].descp}')`;
                    try {
                        const insertResult = await db.promise().query(sqlquery);

                        if (insertResult[0].affectedRows !== 1) {
                            // If any insertion fails, send an error response and exit the loop
                            res.send({ "statusCode": 400, 'status': "user education field insert error" });
                            return;
                        }
                    } catch (insertError) {
                        console.error(insertError);
                        res.send({ "statusCode": 500, 'status': "Internal Server Error" });
                        return;
                    }
                }

                // If all insertions are successful, send a success response
                res.send({ "statusCode": 200, 'status': "user education field insert successfully!!!" });
            }
        });
    }

    else if (obj1.Certification != undefined) {
        OB = obj1.Certification;
        // Check if user already exists
        const checkUserQuery = `SELECT user_id FROM certification WHERE user_id = '${token.userId}'`;
        const userExistsResult = await db.promise().query(checkUserQuery);

        if (userExistsResult[0].length > 0) {
            // User exists, delete existing rows
            const deleteQuery = `DELETE FROM certification WHERE user_id = '${token.userId}'`;
            await db.promise().query(deleteQuery);
        }

        // Insert new data
        for (let i = 0; i < OB.length; i++) {
            insertQuery = `insert into certification (user_id,certificationCourse,certificateID,CertificateVerificationURL,
issueDateMonth,issueDateYear,expiryDateMonth,expiryDateYear) values ('${token.userId}','${OB[i].certificationCourse}','${OB[i].certificateID}','${OB[i].CertificateVerificationURL}','${OB[i].issueDateMonth}',
'${OB[i].issueDateYear}','${OB[i].expiryDateMonth}','${OB[i].expiryDateYear}')`;

            const result = await db.promise().query(insertQuery);

            if (result[0].affectedRows !== 1) {
                res.send({ "statusCode": 400, 'status': "certification field error" });
                return; // Stop further processing if an error occurs
            }
        }
    }


    else if (obj1.Project != undefined) {
        OB = obj1.Project;

        const checkUserQuery = `SELECT user_id FROM project WHERE user_id = '${token.userId}'`;
        const userExistsResult = await db.promise().query(checkUserQuery);

        if (userExistsResult[0].length > 0) {
            // User exists, delete existing rows
            const deleteQuery = `DELETE FROM project WHERE user_id = '${token.userId}'`;
            await db.promise().query(deleteQuery);
        }

        // Insert new data
        for (let i = 0; i < OB.length; i++) {
            insertQuery = `insert into project(user_Id,projectName,projectRole,projectDesc,year,clientCollege,ManagerGuide) values ('${token.userId}',
   '${OB[i].projectName}','${OB[i].projectRole}','${OB[i].projectDesc}','${OB[i].year}','${OB[i].clientCollege}','${OB[i].ManagerGuide}')`


            const result = await db.promise().query(insertQuery);

            if (result[0].affectedRows !== 1) {
                res.send({ "statusCode": 400, 'status': "project field error" });
                return; // Stop further processing if an error occurs
            }
        }
    }



    else if (obj1.Skill != undefined) {
        OB = obj1.Skill;

        const checkUserQuery = `SELECT user_id FROM skill WHERE user_id = '${token.userId}'`;
        const userExistsResult = await db.promise().query(checkUserQuery);

        if (userExistsResult[0].length > 0) {
            // User exists, delete existing rows
            const deleteQuery = `DELETE FROM skill WHERE user_id = '${token.userId}'`;
            await db.promise().query(deleteQuery);
        }

        // Insert new data
        for (let i = 0; i < OB.length; i++) {
            insertQuery = `insert into skill (user_id,skillName,skillRating)values('${token.userId}','${OB[i].skillName}','${OB[i].skillRating}') `


            const result = await db.promise().query(insertQuery);

            if (result[0].affectedRows !== 1) {
                res.send({ "statusCode": 400, 'status': "skill field error" });
                return; // Stop further processing if an error occurs
            }
        }
    }

    else if (obj1.Techskills != undefined) {

        OB = obj1.Techskills;

        const checkUserQuery = `SELECT user_id FROM technical_skills WHERE user_id = '${token.userId}'`;
        const userExistsResult = await db.promise().query(checkUserQuery);

        if (userExistsResult[0].length > 0) {
            // User exists, delete existing rows
            const deleteQuery = `DELETE FROM technical_skills WHERE user_id = '${token.userId}'`;
            await db.promise().query(deleteQuery);
        }

        // Insert new data
        for (let i = 0; i < OB.length; i++) {
            insertQuery = `insert into technical_skills (user_id,skillName,skillRating)values('${token.userId}','${OB[i].skillName}','${OB[i].skillRating}') `;

            const result = await db.promise().query(insertQuery);

            if (result[0].affectedRows !== 1) {
                res.send({ "statusCode": 400, 'status': "Technical skill field error" });
                return; // Stop further processing if an error occurs
            }
        }
    }
    else if (obj1.sociallinks !== undefined) {
        OB = obj1.sociallinks;
        // Check if user already exists
        const checkUserQuery = `SELECT user_id FROM social_link WHERE user_id = '${token.userId}'`;
        const userExistsResult = await db.promise().query(checkUserQuery);

        if (userExistsResult[0].length > 0) {

            // User exists, delete existing rows
            const deleteQuery = `DELETE FROM social_link WHERE user_id = '${token.userId}'`;
            let result = await db.promise().query(deleteQuery);

        }
        // Insert new data
        for (let i = 0; i < OB.length; i++) {
            const insertQuery = `INSERT INTO social_link (user_id, socialLinks) VALUES('${token.userId}', '${OB[i].socialLinks}')`;
            const result = await db.promise().query(insertQuery);

            if (result[0].affectedRows !== 1) {
                res.send({ "statusCode": 400, 'status': "social link field error" });
                return; // Stop further processing if an error occurs
            }
        }
    }

    else if (obj1.Language != undefined) {
        OB = obj1.Language
        sqlquery = `SELECT user_id FROM language WHERE user_id = '${token.userId}'`;
        result = await db.promise().query(sqlquery);
        if (result[0].length > 0) {

            // User exists, delete existing rows
            const deleteQuery = `DELETE FROM language WHERE user_id = '${token.userId}'`;
            let result = await db.promise().query(deleteQuery);

        }
        for (let i = 0; i < OB.length; i++) {
            sqlquery = `insert into  language (user_id,language)values('${token.userId}','${OB[i].language}') `;
            result = await db.promise().query(sqlquery)
            if (result[0].affectedRows != 1) {
                res.send({ "statusCode": 400, 'status': "language field error" })
            }
        }
    }
    else if (obj1.OtherPersonaldetails != undefined) {
        OB = obj1.OtherPersonaldetails
        sqlquery = `select User_id from other_personal_details where User_id = ${token.userId}`;
        result = await db.promise().query(sqlquery)
        if (result[0].length > 0) {
            sqlquery = `DELETE FROM other_personal_details WHERE User_id = '${token.userId}'`;
            await db.promise().query(sqlquery);
        }
        for (let i = 0; i < OB.length; i++) {
            sqlquery = ` INSERT INTO other_personal_details (User_id,dob, gender, address, city, pincode, country, nationality, maritalStatus)
            VALUES ( '${token.userId}', '${OB[i].dob}', '${OB[i].gender}', '${OB[i].address}', '${OB[i].city}', '${OB[i].pincode}', '${OB[i].country}', '${OB[i].nationality}', '${OB[i].maritalStatus}') `;
            result = await db.promise().query(sqlquery)
            if (result[0].affectedRows != 1) {
                res.send({ "statusCode": 400, 'status': "language field error" })
            }
        }
    }


    else if (obj1.Hobbies != undefined) {
        OB = obj1.Hobbies
        sqlquery = `select user_id from hobbies where user_id = ${token.userId}`;
        result = await db.promise().query(sqlquery)
        if (result[0].length > 0) {
            sqlquery = `DELETE FROM hobbies WHERE user_id = '${token.userId}'`;
            await db.promise().query(sqlquery);
        }
        for (let i = 0; i < OB.length; i++) {
            sqlquery = `insert into  hobbies (user_id,hobbies)values('${token.userId}','${OB[i].hobbies}') `;
            result = await db.promise().query(sqlquery)
            if (result[0].affectedRows != 1) {
                res.send({ "statusCode": 400, 'status': "hobbies field error" })
            }
        }
    }
    else if (obj1.Extracurricular != undefined) {
        OB = obj1.Extracurricular;

        sqlquery = `select user_id from extra_curricular_activities where user_id = ${token.userId}`;
        result = await db.promise().query(sqlquery)
        if (result[0].length > 0) {
            sqlquery = `DELETE FROM extra_curricular_activities WHERE user_id = '${token.userId}'`;
            await db.promise().query(sqlquery);
        }
        for (let i = 0; i < OB.length; i++) {
            sqlquery = `insert into  extra_curricular_activities (user_id,activityName,descp)
                values('${token.userId}','${OB[i].activityName}','${OB[i].descp}') `
            result = await db.promise().query(sqlquery)
            if (result[0].affectedRows != 1) {
                res.send({ "statusCode": 400, 'status': "Extra curricular Activities field error" })
            }
        }
    }
    else if (obj1.CustomSection != undefined) {
        OB = obj1.CustomSection
        sqlquery = `select user_id from custom_section where user_id = ${token.userId}`;
        result = await db.promise().query(sqlquery)
        if (result[0].length > 0) {
            sqlquery = `DELETE FROM custom_section WHERE user_id = '${token.userId}'`;
            await db.promise().query(sqlquery);
        }
        for (let i = 0; i < OB.length; i++) {
            sqlquery = `insert into  custom_section (user_id,heading,activityName,descp)
                values('${token.userId}','${OB[i].heading}','${OB[i].activityName}','${OB[i].descp}') `
            result = await db.promise().query(sqlquery)
            if (result[0].affectedRows != 1) {
                res.send({ "statusCode": 400, 'status': "custome section field error" })
            }
        }
    }

})



//Fetch User List.....................................................
router.get('/get-users-list', (req, res) => {
    //select year type integer string like 1 Years,2 Years
    sqlquery = "select * from user";
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userData = result
            res.send({ "statusCode": 200, userData });
        }
    })
})

//Post Year Master---------------------------------------------------
router.post('/post-year-master', (req, res) => {
    sqlquery = `insert into int_year_master (year) values ('${req.body.year}')`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400, 'status': "Invalid email or password" })
        } else {
            res.send({ "statusCode": 200 });
        }
    })
})

//Get/Fetch Year Master List.....................................................
router.get('/get-year-master', (req, res) => {

    //select year type integer string like 1 Years,2 Years
    sqlquery = "select * from int_year_master";
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let yearData = result
            res.send({ "statusCode": 200, yearData });
        }
    })
})


//Get/Fetch Year Master by ID .....................................................
router.get('/get-year-master/:yearid', (req, res) => {
    sqlquery = `SELECT * FROM int_year_master WHERE int_year_id = ${[req.params.yearid]}`
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let yearData = result
            res.send({ "statusCode": 200, yearData });
        }
    })
})

//UPDATE Year Master by ID .....................................................
router.put('/update-year-master', (req, res) => {

    const reqData = {
        year: req.body.year,
        yearid: req.body.yearid
    }
    //select year type integer string like 1 Years,2 Years
    sqlquery = `UPDATE int_year_master SET year=${reqData.year} WHERE int_year_id = ${reqData.yearid}`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }

        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let yearData = result
            res.send({ "statusCode": 200, yearData });
        }
    })
})

//DELETE Year Master by ID .....................................................
router.get('/delete-year-master/:yearid', (req, res) => {
    //select year type integer string like 1 Years,2 Years
    sqlquery = `DELETE FROM int_year_master WHERE int_year_id = ${[req.params.yearid]}`
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }

        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let yearData = result
            res.send({ "statusCode": 200 });
        }
    })
})

//Post Template Master---------------------------------------------------
router.post('/post-template-master', uploadTemplatePic.single("templatePic"), (req, res) => {
    const imgPath = "assest/templatePic/" + req.file.filename;

    const reqData = {
        templateName: req.body.templateName,
        templateType: req.body.templateType,
        templateStatus: req.body.templateStatus
    }
    sqlquery = `insert into template_master (Name, image, type, status) values ('${reqData.templateName}','${imgPath}','${reqData.templateType}','${reqData.templateStatus}')`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400, 'status': "Invalid data" })
        } else {
            res.status(200).json({ message: 'ok' });
        }
    })

})

//UPDATE template Master by ID .....................................................
router.put('/update-template-master/:templateId', uploadTemplatePic.single("templatePic"), (req, res) => {
    const imgPath = "assest/templatePic/" + req.file.filename;
    const reqData = {
        name: req.body.templateName,
        type: req.body.templateType,
        status: req.body.templateStatus,
        templateID: req.params.templateId
    }

    sqlquery = `UPDATE template_master SET name='${reqData.name}', image='${imgPath}', type='${reqData.type}',status='${reqData.status}' WHERE template_id= '${reqData.templateID}'`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }

        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let yearData = result
            res.send({ "statusCode": 200, yearData });
        }
    })
})

//Get/Fetch Template Master List.....................................................
router.get('/get-template-master', (req, res) => {
    sqlquery = "select * from template_master";
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let templateMasterData = result
            res.send({ "statusCode": 200, templateMasterData });
        }
    })
})

//DELETE Template Master by ID .....................................................
router.get('/delete-template-master/:templateId', (req, res) => {
    //select year type integer string like 1 Years,2 Years
    sqlquery = `DELETE FROM template_master WHERE template_id= ${[req.params.templateId]}`
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let yearData = result
            res.send({ "statusCode": 200 });
        }
    })
})

//get package Master data by templateID .....................................................
router.get('/get-template-master/:templateId', (req, res) => {
    sqlquery = `select * from template_master WHERE template_id = ${req.params.templateId}`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let templateMasterData = result
            res.send({ "statusCode": 200, templateMasterData });
        }
    })
})


// post credit pont ------------------------------------------------------------------------
router.post('/post-user-credit-point', (req, res) => {
    sqlquery = `insert into credit_point (user_id, credit_point) values ('${req.body.year}')`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400, 'status': "failed to insert credit point!!!" })
        } else {
            res.send({ "statusCode": 200 });
        }
    })
})

// get credit pont ------------------------------------------------------------------------
router.get('/get-credit-point', (req, res) => {
    const token = jwtverify(req);
    sqlquery = `select credit_point from credit_point WHERE user_id = ${token.userId}`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400, 'status': "failed to get credit point!!!" })
        } else {

            let creditPoint = result[0];
            res.send({ "statusCode": 200, creditPoint });
        }
    })
})

// get credit pont ------------------------------------------------------------------------
router.post('/update-credit-point', (req, res) => {
    let obj = escapString(req.body.value)
    const token = jwtverify(req);
    sqlquery = `UPDATE credit_point SET credit_point='${req.body.value}' WHERE user_id= ${token.userId}`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400, 'status': "failed to get credit point!!!" })
        } else if (result.affectedRows === 1) {
            let creditPoint = result;
            res.send({ "statusCode": 200, creditPoint, 'message': 'credit point updated' });

        }
    })
})

//Post package Master---------------------------------------------------
router.post('/post-package-master', (req, res) => {

    const reqData = {
        packageName: req.body.packageName,
        price: req.body.price,
        numOfTemplate: req.body.numOfTemplate,
        coverLetter: req.body.coverLetter,
        creditPointsAI: req.body.creditPointsAI,
        deductCreditPoint: req.body.deductCreditPoint,
        premium10x: req.body.premium10x,
        waterMark: req.body.waterMark,
        premiumTemplate: req.body.premiumTemplate,
        downloadOption: req.body.downloadOption,
        emailSupport: req.body.emailSupport,
        phoneSupport: req.body.phoneSupport,
        portfolio: req.body.portfolio,
        customDomain: req.body.customDomain
    }
    sqlquery = `insert into package_list (package_name, price, num_of_template,
        cover_letter,credit_points,credit_point_deduct,premium_powerful_AI,water_mark,premium_template,
        download_option,email_support,phone_support,portfolio,custom_domain)
        values ('${reqData.packageName}',
        '${reqData.price}',
        '${reqData.numOfTemplate}',
        '${reqData.coverLetter}',
        '${reqData.creditPointsAI}',
        '${reqData.deductCreditPoint}',
        '${reqData.premium10x}',
         '${reqData.waterMark}',
        '${reqData.premiumTemplate}',
        '${reqData.downloadOption}',
        '${reqData.emailSupport}',
        '${reqData.phoneSupport}',
        '${reqData.portfolio}',
        '${reqData.customDomain}'
        )`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400, 'status': "Invalid data" })
        } else {
            res.send({ "statusCode": 200 });
        }
    })
})

//Get/Fetch package Master List.....................................................
router.get('/get-package-master', (req, res) => {
    sqlquery = "select * from package_list";
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let packageListData = result
            res.send({ "statusCode": 200, packageListData });
        }
    })
})

//get package Master data by templateID .....................................................
router.get('/get-package-master/:packageId', (req, res) => {
    sqlquery = `select * from package_list WHERE package_list_id = ${req.params.packageId}`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let packageData = result
            res.send({ "statusCode": 200, packageData });
        }
    })
})

//UPDATE package Master by ID .....................................................
router.put('/update-package-master', (req, res) => {
    const reqData = {
        packageName: req.body.templateData.package_name,
        price: req.body.templateData.price,
        totalAmount: req.body.templateData.credential_amount,
        templateId: req.body.packageId
    }

    sqlquery = `UPDATE package_list SET package_name='${reqData.packageName}', price='${reqData.price}', credential_amount='${reqData.totalAmount}' WHERE package_list_id= '${reqData.templateId}'`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }

        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let yearData = result
            res.send({ "statusCode": 200, yearData });
        }
    })
})

//DELETE package Master by ID .....................................................
router.get('/delete-package-master/:packageId', (req, res) => {
    sqlquery = `DELETE FROM package_list WHERE package_list_id= ${[req.params.packageId]}`
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let yearData = result
            res.send({ "statusCode": 200 });
        }
    })
})

router.get('/get-templates', async (req, res) => {
    const flag = req.query.flag
    sqlquery = `SELECT * FROM template_master LIMIT ${flag},6 `;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let templateMasterData = result
            res.send({ "statusCode": 200, templateMasterData });
        }
    })

})

//Post user subscription data ---------------------------------------------------
router.post('/post-user-subscription-data', async (req, res) => {
    const token = jwtverify(req);
    const packageId = req.body.packageId;
    sqlquery = `select user_id from subscription where user_id = ${token.userId}`;
    result = await db.promise().query(sqlquery)
    if (result[0].length == 1) {
        sqlquery = `update subscription set package_id = '${packageId}' where user_id = ${token.userId}`;
        result = await db.promise().query(sqlquery)
    }
    else {
        sqlquery = `insert into subscription(user_id, package_id) values('${token.userId}', '${packageId}')`;
        db.query(sqlquery, (err, result, fields) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
            }
            if (result.length == 0) {
                res.send({ "statusCode": 400, 'status': "Invalid data" })
            } else {
                res.send({ "statusCode": 200 });
            }
        })
    }
})

//Post user subscription data ---------------------------------------------------
router.post('/post-default-credt-points', (req, res) => {

    const defaultCreditPoints = req.body.defaultCreditPoint;
    const deductCreditPoint = req.body.deductCreditPoint;
    sqlquery = `insert into  default_credit_point (credit_points,credit_points_deduct) values ('${defaultCreditPoints}','${deductCreditPoint}')`
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400, 'status': "Invalid data" })
        } else {
            res.send({ "statusCode": 200 });
        }
    })
})


// get default credit pont ------------------------------------------------------------------------
router.get('/get-default-credit-point-deduct', (req, res) => {

    sqlquery = `select credit_points_deduct from default_credit_point`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400, 'status': "failed to get credit point!!!" })
        } else {

            let defaultCreditPointDeduct = result[0];
            res.send({ "statusCode": 200, defaultCreditPointDeduct });
        }
    })
})


//my details---------------------------
router.get('/mydetails', (req, res) => {
    const token = jwtverify(req);
    sqlquery = `SELECT user_name, email, profile_pic, mode FROM user WHERE user_id = ${token.userId}`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400 })
        } else {
            let userData = result
            res.send({ "statusCode": 200, userData });
        }
    })
})

//get-current-plan--------------------
router.get('/get-current-plan', async (req, res) => {

    const token = jwtverify(req);
    sqlquery = `select package_id,start_date,expiration_date from subscription where user_id = '${token.userId}'`;
    result = await db.promise().query(sqlquery)

    if (result[0].length > 0) {
        sqlquery = `select * from package_list where package_list_id = '${result[0][0].package_id}'`;
        let packageList = await db.promise().query(sqlquery)
        if (packageList[0].length > 0) {
            let package = packageList[0]
            let datetime = result[0]
            let currentDT = subscriptionExpire(0)
            var date1 = parseCustomDate(result[0][0].expiration_date);
            var date2 = parseCustomDate(currentDT[0]);
            let expairedDate = date1 > date2
            res.send({ "statusCode": 200, 'status': "package found", package, "expairedDate": expairedDate })
        }
        else {
            res.send({ "statusCode": 401, 'status': "somthing is problem" })
        }
    }
    else {
        res.send({ "statusCode": 400, 'status': "package not found" })
    }

})

//get-user-credit-point----------
router.get('/get-user-credit-point', (req, res) => {
    const token = jwtverify(req);
    sqlquery = `select credit_point from credit_point where user_id = '${token.userId}'`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400, 'status': "failed to get credit point!!!" })
        } else {
            res.send({ "statusCode": 200, result });
        }
    })
})


//update-profile------------------------------
router.post('/update-profile', uploadImg.single("profilePic"), async (req, res) => {
    const token = jwtverify(req);
    let imgPath
    if (req.file == undefined) {
        imgPath = req.body.profilePic
    }
    else {
        imgPath = "http://localhost:4000/assest/profilePic/" + req.file.filename;
    }
    if (req.body.password != undefined) {
        sqlquery = `SELECT password, mode FROM user WHERE user_id = ${token.userId} and password = ${req.body.password}`;
        result = await db.promise().query(sqlquery)
    }
    else {
        result = [[1]]
    }
    if (result[0].length == 1) {
        const data = {
            "userId": token.userId,
            "name": req.body.name,
            "pic": imgPath,
            "mode": result[0][0].mode
        }
        let newToken = jwt.sign(data, "vikashrakesh1234569898"),
            sqlquery = `UPDATE user SET token = '${newToken}', user_name = '${req.body.name}', profile_pic = '${imgPath}' WHERE user_id = ${token.userId}`;
        result = await db.promise().query(sqlquery)
        if (result[0].affectedRows == 1) {
            res.send({ "statusCode": 200, "token": newToken })
        }
        else {
            res.send({ "statusCode": 401, "status": "Somthing is problem" })
        }

    }
    else {
        res.send({ "statusCode": 400, "status": "Wrong password" })
    }
})

//Post user cover page data ---------------------------------------------------
router.post('/post-user-cover-page', async (req, res) => {
    const token = jwtverify(req);
    const content = req.body.content;
    const companyName = req.body.companyName;

    sqlquery = `insert into user_cover_page (user_id,company_name, cover_page) values('${token.userId}','${companyName}', '${content}')`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {

            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400, 'status': "Invalid data" })
        } else {
            res.send({ "statusCode": 200 });
        }
    })

})


//get cover page data---------------------------
router.get('/get-user-cover-letter', (req, res) => {

    const token = jwtverify(req);

    sqlquery = `SELECT * FROM user_cover_page WHERE user_id = ${token.userId}`;
    try {
        db.query(sqlquery, (err, result, fields) => {

            if (err) {

                return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
            }
            if (result.length == 0) {
                res.send({ "statusCode": 400 })
            } else {

                let userData = result;
                res.send({ "statusCode": 200, userData });
            }
        })
    } catch (error) {
        console.error(error);
        res.status(500).send({ 'status': 500, 'error': 'Internal Server Error' });
    }
})

//get cover page data by cover page id ---------------------------
router.get('/get-user-cover-by-id/:coverPageId', (req, res) => {

    const token = jwtverify(req);

    sqlquery = `SELECT * FROM user_cover_page WHERE cover_page_id = ${[req.params.coverPageId]}`
    try {
        db.query(sqlquery, (err, result, fields) => {
            if (err) {

                return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
            }
            if (result.length == 0) {
                res.send({ "statusCode": 400 })
            } else {
                let userData = result;
                res.send({ "statusCode": 200, userData });
            }
        })
    } catch (error) {
        console.error(error);
        res.status(500).send({ 'status': 500, 'error': 'Internal Server Error' });
    }
})

//update cover page data---------------------------
router.post('/update-user-cover-page-by-id/:coverPageId', (req, res) => {

    try {
        const token = jwtverify(req);
        sqlquery = `UPDATE user_cover_page SET cover_page = '${req.body.coverPageData}', company_name='${req.body.companyName}' WHERE cover_page_id  = ${req.params.coverPageId}`;

        db.query(sqlquery, (err, result, fields) => {
            if (err) {

                return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
            }
            if (result.length == 0) {
                res.send({ "statusCode": 400 })
            } else {
                let userData = result
                res.send({ "statusCode": 200 });
            }
        })
    } catch (error) {
        console.error(error);
        res.status(500).send({ 'status': 500, 'error': 'Internal Server Error' });
    }
})


router.get('/get-package-name', (req, res) => {
    const token = jwtverify(req);
    sqlquery = `SELECT package_list_id, package_name FROM package_list`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {

            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400 })
        } else {
            res.send({ "statusCode": 200, result });
        }
    })
})

router.get('/conform-tmp', async (req, res) => {
    const token = jwtverify(req);
    const tmp_num = req.query.tmp_num
    sqlquery = `SELECT package_list_id, type FROM template_master where template_number = ${tmp_num}`;
    result = await db.promise().query(sqlquery)
    if (result[0].length > 0) {
        if (result[0][0].type == 0) {
            res.send({ "statusCode": 200 })
            return;
        }
        sqlquery = `select package_id,expiration_date from subscription where user_id =${token.userId} and package_id =${result[0][0].package_list_id} `
        result = await db.promise().query(sqlquery)
        if (result[0].length > 0) {

            let currentDT = subscriptionExpire(0)
            var date1 = parseCustomDate(result[0][0].expiration_date);
            var date2 = parseCustomDate(currentDT[0]);
            if (date1 > date2) {
                res.send({ "statusCode": 200 })
            }
            else {
                res.send({ "statusCode": 400, "status": "Your plan has been expaired." })
            }

        }
        else {
            res.send({ "statusCode": 400, "status": "Please buy this premium template." })
        }
    } else {
        res.send({ "status": 400, "status": 'Template not found.' })
    }
})

router.post('/procced-payment', async (req, res) => {
    let amount = req.body.pay_ammount;
    try {
        const options = {
            amount: amount * 100, // amount == Rs 10
            currency: "INR",
            receipt: "receipt#1",
            payment_capture: 1,
            // 1 for automatic capture // 0 for manual capture
        };
        instance.orders.create(options, async function (err, order) {

            if (err) {
                return res.status(500).json({
                    message: "Something Went Wrong",
                });
            }
            else {
                const token = jwtverify(req);
                const packageId = req.body.packageId;
                sqlquery = `insert into payment_summary (user_id,package_list_id,name,email,phone,address,city,pincode,country,pay_ammount,pay_order_id	) values ('${token.userId}','${packageId}','${req.body.name}','${req.body.email}','${req.body.phone}','${req.body.address}','${req.body.city}','${req.body.pincode}','${req.body.country}','${req.body.pay_ammount}','${order.id}')`;
                result = await db.promise().query(sqlquery);
                if (result[0].affectedRows == 1) {
                    res.send({ 'statusCode': 200, order })
                }
                else {
                    res.send({ 'statusCode': 400 })
                }
            }
        });
    } catch (err) {
        return res.status(500).json({
            message: "Something Went Wrong",
        });
    }

})
router.post('/procced-payment-status', async (req, res) => {
    const token = jwtverify(req);
    const obj = req.body
    let payStatus
    let order_id
    let payment_id
    if (obj.razorpay_signature != undefined) {
        payStatus = "Success"
        order_id = obj.razorpay_order_id
        payment_id = obj.razorpay_payment_id
    }
    else {
        payStatus = "Failed"
        order_id = obj.error.metadata.order_id
        payment_id = obj.error.metadata.payment_id
    }
    sqlquery = `update payment_summary SET payment_id ='${payment_id}', payment_status ='${payStatus}', razorpay_signature ='${obj.razorpay_signature}' where pay_order_id='${order_id}'`;
    let result = await db.promise().query(sqlquery);
    if (result[0].affectedRows == 1) {
        if (obj.razorpay_signature != undefined) {
            sqlquery = `select package_list_id from payment_summary where pay_order_id ='${order_id}' and payment_status='Success'`
            result = await db.promise().query(sqlquery);
            if (result[0].length > 0) {
                sqlquery = `select 	subscription_id from subscription where user_id ='${token.userId}'`
                let result0 = await db.promise().query(sqlquery);
                let datetime = subscriptionExpire(30)
                if (result0[0].length == 0) {

                    sqlquery = `insert into subscription (user_id,package_id,start_date,expiration_date,status) values ('${token.userId}','${result[0][0].package_list_id}','${datetime[0]}','${datetime[1]}','active')`
                }
                else {
                    sqlquery = `update subscription set package_id = '${result[0][0].package_list_id}',start_date='${datetime[0]}',expiration_date='${datetime[1]}',status='active' where user_id ='${token.userId}'`
                }

                db.query(sqlquery, (err, result1, fields) => {
                    if (err) {

                        return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                    }
                    if (result1.affectedRows > 0) {
                        sqlquery = `select credit_points from package_list where package_list_id = '${result[0][0].package_list_id}'`
                        db.query(sqlquery, (err, result2, fields) => {
                            if (err) {

                                return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                            }
                            if (result2.length > 0) {
                                sqlquery = `select credit_point from credit_point where user_id='${token.userId}'`
                                db.query(sqlquery, (err, result3, fields) => {
                                    if (err) {

                                        return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                                    }
                                    sqlquery = `update credit_point SET credit_point ='${result2[0].credit_points + result3[0].credit_point}' where user_id='${token.userId}'`;
                                    db.query(sqlquery, (err, result4, fields) => {
                                        if (err) {

                                            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                                        }
                                        if (result4.affectedRows > 0) {
                                            res.send({ "statusCode": 200, "status": "Payment successful" })
                                        }
                                        else {
                                            res.send({ "statusCode": 401, "status": "Somthing is problem Please contact us" })
                                        }

                                    })
                                })
                            }
                        })
                    }
                });

            }
        }
        else {
            res.send({ "statusCode": 401, "status": "Payment failed" })
        }
    }
})
router.get('/get-package', (req, res) => {
    sqlquery = `select package_name, price,image from package_list WHERE package_list_id = ${req.query.packageId}`;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }

        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let packageData = result
            res.send({ "statusCode": 200, packageData });
        }
    })
})

//Get User Detail.....................................................
router.get('/get-users-detail/:id', (req, res) => {
    //select year type integer string like 1 Years,2 Years
    sqlquery = `SELECT * FROM user WHERE user_id = ${[req.params.id]}`
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userData = result
            res.send({ "statusCode": 200, userData });
        }
    })
})

// Send Verification Email-------------------------------------------------
router.post('/send-validation-email', async (req, res) => {
    //  var reqEmail = escapString(req.body.inputEmail);
    isEmailValidated: false;
    var reqEmail = req.body.inputEmail;

    // Generate a validation token
    const validationToken = randomToken(35);

    sqlquery = `SELECT * FROM user WHERE email ='${reqEmail}'`;

    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 1) {
            sqlquery = `SELECT * FROM email_verification WHERE user_email ='${reqEmail}'`;
            db.query(sqlquery, (err, result, fields) => {
                if (err) {
                    console.error(err);
                    return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                }
                if (result.length == 1) {
                    //  email exist - update token query
                    //   sqlquery = `update email_verification SET token ='${validationToken}'`;
                    sqlquery = `update email_verification SET token ='${validationToken}' where user_email='${reqEmail}'`;

                    db.query(sqlquery, (err, result, fields) => {
                        if (err) {
                            console.error(err);
                            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                        }
                        if (result.affectedRows == 1) {

                            // code for send email verification link
                            // Create a validation link
                            const validationLink = `http://localhost:3000/verify?validationToken=${validationToken}`;

                            // Configure and send email with Nodemailer
                            const transporter = nodemailer.createTransport({
                                service: 'Gmail', // Use your email service
                                auth: {
                                    user: 'visupater@gmail.com', // Your email
                                    pass: 'gxuwysdssjnehmdw',  // Your email password
                                },
                            });

                            const mailOptions = {
                                to: `${reqEmail}`,
                                from: `${reqEmail}`,
                                subject: 'Email Validation from Magic Point',
                                text: `Click the following link to validate your email: ${validationLink}`,
                            };

                            transporter.sendMail(mailOptions, (error, info) => {
                                if (error) {
                                    console.error(error);
                                    res.status(500).send('Error sending email');
                                } else {
                                    //  res.status(200).send('Email sent successfully');
                                    res.send({ "statusCode": 200, info, message: "Email sent successfully" });
                                }
                            });

                        }
                    })
                }
                else if (result.length == 0) {
                    // write insert query for email and token
                    sqlquery = `insert into email_verification (user_email,token) values ('${reqEmail}','${validationToken}')`;
                    db.query(sqlquery, (err, result, fields) => {
                        if (err) {
                            console.error(err);
                            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                        }
                        if (result.affectedRows == 1) {
                            // code for send email verification link
                            // Create a validation link
                            const validationLink = `http://localhost:3000/verify?validationToken=${validationToken}`;

                            // Configure and send email with Nodemailer
                            const transporter = nodemailer.createTransport({
                                service: 'Gmail', // Use your email service
                                auth: {
                                    user: 'visupater@gmail.com', // Your email
                                    pass: 'gxuwysdssjnehmdw',  // Your email password
                                },
                            });

                            const mailOptions = {
                                to: `${reqEmail}`,
                                from: `${reqEmail}`,
                                subject: 'Email Validation from Magic Point',
                                text: `Click the following link to validate your email: ${validationLink}`,
                            };

                            transporter.sendMail(mailOptions, (error, info) => {
                                if (error) {
                                    console.error(error);
                                    res.status(500).send('Error sending email');
                                } else {
                                    // res.status(200).send('Email sent successfully');
                                    res.send({ "statusCode": 200, info, message: "Email sent successfully" });
                                }
                            });

                        }
                    })

                } else {

                    res.send({ "statusCode": 400, msg: "invalid email" });
                }
            })
        }
        else {
            res.status(404).send({ 'message': 'No records found for the given email.' });
        }

    })


});

// Validate the Email Address-----------------------------------------
router.get('/validate-email/:token', (req, res) => {
    const reqtoken = req.params.token;

    sqlquery = `SELECT token FROM email_verification WHERE token = "${reqtoken}"`;
    db.query(sqlquery, function (error, results, fields) {
        if (error) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (results.length >= 1 && reqtoken === results[0].token) {

            res.send({ "statusCode": 200, "message": 'Email validated successfully' });
        } else {

            res.status(400).send('Invalid validation token');
        }

    });
});

// change password-----------------------------------------
router.post('/change-password', (req, res) => {
    const reqtoken = req.body.token;
    const reqBody = req.body.inputValues.password;
    sqlquery = `SELECT * FROM email_verification WHERE token = "${reqtoken}"`;

    db.query(sqlquery, (err, results, fields) => {

        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (results.length >= 1 && reqtoken === results[0].token) {

            let userEmail = results[0].user_email;
            sqlquery = `SELECT * FROM user WHERE email = "${userEmail}"`;

            db.query(sqlquery, (err, results, fields) => {
                if (err) {
                    console.error(err);
                    return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                }
                if (results.length >= 1 && userEmail === results[0].email) {

                    sqlquery = `update user SET password ='${reqBody}' where email='${results[0].email}' `;
                    db.query(sqlquery, (err, result, fields) => {
                        if (err) {
                            console.error(err);
                            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                        }
                        if (result.affectedRows == 1) {
                            res.status(200).send({ "statusCode": 200, "message": 'Password update successfully' });
                        }
                        else {
                            res.status(400).send('Email not found!!!!');
                        }
                    });
                } else {
                    res.status(400).send('Email not found!!!');
                }
            })
        } else {
            res.status(400).send('Invalid validation token');
        }

    });
});

router.post('/post-admin-user', (req, res) => {
    let pic = req.body.picture
    let obj = escapString(req.body);
    //Checking email is exist or not............................................
    sqlquery = `select admin_email from admin where admin_email = '${obj.email}'`;

    db.query(sqlquery, (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            sqlquery = `insert into admin(admin_user_name, admin_email, admin_password, admin_type) values('${obj.name}', '${obj.email}', '${obj.password}', '${obj.adminType}')`;
            db.query(sqlquery, (err, result, fields) => {
                if (err) {
                    console.error(err);
                    return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                }
                const data = {
                    "userId": result.insertId,
                    "name": obj.name,
                    "type": obj.adminType,
                }
                let token = jwt.sign(data, "vikashrakesh1234569898"),
                    sqlquery = `update admin SET token ='${token}' where admin_id='${result.insertId}' `
                db.query(sqlquery, (err, result) => {
                    if (err) {
                        console.error(err);
                        return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
                    }

                    if (result.affectedRows == 1) {
                        res.send({
                            "statusCode": 200,
                            "status": "User added successfull",
                        })
                    }
                    else {
                        res.send({
                            "statusCode": 401,
                            "status": "Somthing is problem",
                        })
                    }

                })

            });
        }
        else {
            res.send({ "statusCode": 400, "status": "This email Id has been already Exist " })
        }
    })
})

router.post('/adminlogin', (req, res) => {

    obj = escapString(req.body.inputValues);
    sqlquery = `select token from admin where admin_email ='${obj.email}' and admin_password='${obj.password}' `;
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "statusCode": 400, 'status': "Invalid email or password" })
        } else {
            res.send({ "statusCode": 200, "token": result[0].token });
        }
    })
})


//Get Work Exp Detail by User ID.....................................................
router.get('/get-users-work-exp-detail', (req, res) => {
    const token = jwtverify(req);

    //select year type integer string like 1 Years,2 Years
    sqlquery = `SELECT * FROM work_experience WHERE user_id = ${token.userId}`
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userWorkExpData = result
            res.send({ "statusCode": 200, userWorkExpData });
        }
    })
})

//Get User Education Detail by User ID.....................................................
router.get('/get-users-education-detail', (req, res) => {
    const token = jwtverify(req);
    //select year type integer string like 1 Years,2 Years
    sqlquery = `SELECT * FROM education WHERE user_Id = ${token.userId}`
    db.query(sqlquery, (err, result, fields) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userEducationData = result
            res.send({ "statusCode": 200, userEducationData });
        }
    })
})

//Get User Certificate Detail by User ID.....................................................
router.get('/get-users-certification-detail', (req, res) => {
    const token = jwtverify(req);
    //select year type integer string like 1 Years,2 Years
    sqlquery = `SELECT * FROM certification WHERE user_Id = ${token.userId}`
    db.query(sqlquery, (err, result, fields) => {

        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userCertificationData = result
            res.send({ "statusCode": 200, userCertificationData });
        }
    })
})

//Get User project Detail by User ID.....................................................
router.get('/get-users-project-detail', (req, res) => {
    const token = jwtverify(req);
    //select year type integer string like 1 Years,2 Years
    sqlquery = `SELECT * FROM project WHERE user_Id = ${token.userId}`
    db.query(sqlquery, (err, result, fields) => {

        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userProjectData = result
            res.send({ "statusCode": 200, userProjectData });
        }
    })
})

//Get User skill Detail by User ID.....................................................
router.get('/get-users-skill-detail', (req, res) => {
    const token = jwtverify(req);
    //select year type integer string like 1 Years,2 Years
    sqlquery = `SELECT * FROM skill WHERE user_Id = ${token.userId}`
    db.query(sqlquery, (err, result, fields) => {

        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userSkillData = result
            res.send({ "statusCode": 200, userSkillData });
        }
    })
})

//Get User TEchnical skill Detail by User ID.....................................................
router.get('/get-users-tech-skill-detail', (req, res) => {
    const token = jwtverify(req);
    //select year type integer string like 1 Years,2 Years
    sqlquery = `SELECT * FROM technical_skills WHERE user_Id = ${token.userId}`
    db.query(sqlquery, (err, result, fields) => {

        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userTechSkillData = result
            res.send({ "statusCode": 200, userTechSkillData });
        }
    })
})

router.get('/get-rusume-data', async (req, res) => {
    const token = jwtverify(req);
    const queryString = req.query
    switch (queryString.field) {
        case "PD":
            sqlquery = `select name, profile_pic, email, phone, workExperienceyear, workExperiencemonth, resumeHeadline, summary from personal_details where user_id = ${token.userId}`;
            result = await db.promise().query(sqlquery)
            if (result[0].length > 0) {
                res.send({ "statusCode": 200, "result": result[0] })
            }
            break;
        default:
        // code block
    }

})

//Get User Social link Detail by User ID.....................................................
router.get('/get-users-social-link-detail', (req, res) => {
    const token = jwtverify(req);
    //select year type integer string like 1 Years,2 Years
    sqlquery = `SELECT * FROM social_link WHERE user_Id = ${token.userId}`
    db.query(sqlquery, (err, result, fields) => {

        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userSocialLinkData = result
            res.send({ "statusCode": 200, userSocialLinkData });
        }
    })
})

//Get User language Detail by User ID.....................................................
router.get('/get-users-language-detail', (req, res) => {
    const token = jwtverify(req);
    //select year type integer string like 1 Years,2 Years
    sqlquery = `SELECT * FROM language WHERE user_Id = ${token.userId}`
    db.query(sqlquery, (err, result, fields) => {

        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userLanguageData = result
            res.send({ "statusCode": 200, userLanguageData });
        }
    })
})

//Get User other PS Detail by User ID.....................................................
router.get('/get-users-other-ps-details', (req, res) => {
    const token = jwtverify(req);
    //select year type integer string like 1 Years,2 Years
    sqlquery = `SELECT * FROM other_personal_details WHERE user_Id = ${token.userId}`
    db.query(sqlquery, (err, result, fields) => {

        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userOtherPSData = result
            res.send({ "statusCode": 200, userOtherPSData });
        }
    })
})

//Get User hobbies  Detail by User ID.....................................................
router.get('/get-users-hobbies-details', (req, res) => {
    const token = jwtverify(req);
    //select year type integer string like 1 Years,2 Years
    sqlquery = `SELECT * FROM hobbies WHERE user_Id = ${token.userId}`
    db.query(sqlquery, (err, result, fields) => {

        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userHobbiesData = result
            res.send({ "statusCode": 200, userHobbiesData });
        }
    })
})

//Get User extra curricular activities   Detail by User ID.....................................................
router.get('/get-users-extra-curricular-details', (req, res) => {
    const token = jwtverify(req);
    //select year type integer string like 1 Years,2 Years
    sqlquery = `SELECT * FROM extra_curricular_activities WHERE user_Id = ${token.userId}`
    db.query(sqlquery, (err, result, fields) => {

        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userExtraCurricularData = result
            res.send({ "statusCode": 200, userExtraCurricularData });
        }
    })
})

//Get User custom secton Detail by User ID.....................................................
router.get('/get-users-custom-section-details', (req, res) => {
    const token = jwtverify(req);
    //select year type integer string like 1 Years,2 Years
    sqlquery = `SELECT * FROM custom_section WHERE user_Id = ${token.userId}`
    db.query(sqlquery, (err, result, fields) => {

        if (err) {
            console.error(err);
            return res.status(500).json({ "statusCode": 500, "status": "Internal Server Error" });
        }
        if (result.length == 0) {
            res.send({ "status": 400 })
        } else {
            let userCustomSectionData = result
            res.send({ "statusCode": 200, userCustomSectionData });
        }
    })
})

module.exports = router;