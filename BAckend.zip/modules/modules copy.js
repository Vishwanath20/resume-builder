//var mysql = require('mysql');
const multer = require("multer")
const axios = require('axios');
const jwt = require("jsonwebtoken")
const mysql = require('mysql2');

// function Con() {
//   // let con = mysql.createConnection({
//   //     host: "localhost",
//   //     user: "root",
//   //     database: "resumebuilderdb"
//   //   });
//   let con = mysql.createConnection({
//     host: "resumbebuilder.cp6ut16gcm0c.ap-south-1.rds.amazonaws.com",
//     user: "dev_team",
//     password: "32l6O]OjbERzLf1O",
//     database: "db_magic_point"

//   });

//   con.connect((err) => {
//     if (err) {
//       console.log(err)
//       console.log("Connection denided")
//       return;
//     }
//     console.log("DB-Connection-Successfulllllyyy")
//   });
//   return con;
// }


function Con() {
  try {
    let con = mysql.createConnection({
      host: "resumbebuilder.cp6ut16gcm0c.ap-south-1.rds.amazonaws.com",
      user: "dev_team",
      password: "32l6O]OjbERzLf1O",
      database: "db_magic_point"

    });

    con.connect((err) => {
      if (err) {
        console.error("Error connecting to the database:", err.message);
        return;
      }
      console.log("DB-Connection-Successfully");
    });

    // Handle unexpected errors during the execution of the code here

    return con;
  } catch (error) {
    console.error("An unexpected error occurred:", error.message);
    // You can decide what to do in case of an unexpected error, such as logging or throwing the error again
    throw error;
  }
}






const upload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, "assest/profilePic");
    },
    filename: function (req, file, cb) {
      cb(null, file.fieldname + "_" + Date.now() + ".jpg");
    }
  })
});

const uploadTemplatePic = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, "assest/templatePic");
    },
    filename: function (req, file, cb) {
      cb(null, file.fieldname + "_" + Date.now() + ".jpg");
    }
  })
});

const jwtVerify = (req) => {
  if (req.headers.authorization === undefined) {
    return undefined;
  }
  let token = req.headers.authorization.replace('Bearer', '');
  token = token.trim();
  const decoded = jwt.verify(token, 'vikashrakesh1234569898', function (err, decoded) {
    return decoded;
  });
  return decoded
}
const sendpushNotify = async (contents, url) => {
  const options = {
    method: 'POST',
    url: 'https://onesignal.com/api/v1/notifications',
    headers: {
      accept: 'application/json',
      Authorization: 'Basic OGQ2N2UxMTYtNDBmYi00ZGY2LTgwNDYtOTczOTdmMzYyMDMx',
      'content-type': 'application/json'
    },
    data: {
      included_segments: ['Subscribed Users'],
      app_id: "9c0feafd-fd31-479f-be1a-7ab9c8c9193e",
      // headings:{en:headings},
      contents: { en: contents },
      url: url,
    }
  };
  const resp = await axios.request(options);
  return resp.data;
}
const escapString = (data) => {
  if (Object.keys(data).length > 0) {
    const obj = {}
    for (var key in data) {
      var value = data[key].replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '')
      obj[key] = value
    }
    return obj;
  }
}
const subscriptionExpire = (afterDays) => {
  const currentDate = new Date();

  // Add specified number of days to the current date
  const newDate = new Date(currentDate);
  newDate.setDate(currentDate.getDate() + afterDays);

  // Format dates as "YYYY-MM-DD HH:mm:ss" in Indian timezone
  const formatOptions = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZone: 'Asia/Kolkata'
  };

  const formatDateTime = (date) => {
    return date.toLocaleString('en-IN', formatOptions)
      .replace(/\//g, '-')
      .replace(',', ''); // Remove the comma
  };

  const currentDateTimeFormatted = formatDateTime(currentDate);
  const newDateTimeFormatted = formatDateTime(newDate);

  return [currentDateTimeFormatted, newDateTimeFormatted];
};
function parseCustomDate(dateStr) {
  var parts = dateStr.match(/(\d+)-(\d+)-(\d+) (\d+):(\d+):(\d+) ([apm]+)$/);
  
  if (parts === null) {
      throw new Error("Invalid date format");
  }

  var year = parseInt(parts[3]);
  var month = parseInt(parts[2]) - 1; // Months are 0-indexed
  var day = parseInt(parts[1]);
  var hours = parseInt(parts[4]) % 12 + (parts[7].toLowerCase() === 'pm' ? 12 : 0);
  var minutes = parseInt(parts[5]);
  var seconds = parseInt(parts[6]);

  return new Date(year, month, day, hours, minutes, seconds);
}
// const sendVerificationEmail = (reqEmail, validationToken) => {
//   // Create a validation link
//   //  const validationLink = `http://localhost:3000/verifyEmail/${validationToken}`;
// }

module.exports = {
  connection: Con(),
  uploadImg: upload,
  uploadTemplatePic: uploadTemplatePic,
  jwtverify: jwtVerify,
  sendpushNotify,
  escapString,
  subscriptionExpire,
  parseCustomDate
}