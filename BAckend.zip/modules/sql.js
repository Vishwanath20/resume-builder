const push = require("node-router/lib/push")

const sqlQuery = (queryType, table, where, columnname, data) => {
    switch (queryType) {
        case "INSERT":
            let column = []
            let values = []
            for (var key in data) {
                column.push(key)
                values.push("'" + data[key] + "'")
            }
            column = column.join();
            values = values.join();
            return `${queryType} INTO ${table} (${column}) VALUES (${values})`;
        case "SELECT":
            return `${queryType} ${columnname} FROM ${table} ${where ?where : " "};`
        case "UPDATE":
            delete data.id;
            let query = []
            for (var key in data) {
                const newData = key + "=" + "'" + data[key] + "'"
                query.push(newData)
            }
            const newData = query.join();
            const sql = `${queryType} ${table} SET ${newData} WHERE ${where};`
            return sql;
        case "DELETE":
            return `${queryType} FROM ${table} WHERE ${where};`
        default:
            return;
    }

}

module.exports = {
    sqlQuery
}