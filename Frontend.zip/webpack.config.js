const webpack = require('webpack');
const dotenv = require('dotenv');
const { merge } = require('webpack-merge');
// Load environment variables from the appropriate .env file
const envFile = process.env.NODE_ENV === 'development' ? '.env.development' : '.env.production';
const envVariables = dotenv.config({ path: envFile }).parsed;

// Pass environment variables to the DefinePlugin
const definePlugin = new webpack.DefinePlugin({
    'process.env': JSON.stringify(envVariables),
});

// Your webpack configuration
module.exports = {
    // ... other configuration options ...

    plugins: [definePlugin],
};
