import React, { useState, useEffect } from 'react';
import "../css/OtherPersonaldetails.css";
import axios from "axios";
import Cookies from 'js-cookie';
import { apiUrl, jwtVerify } from '../../function';

export default function Otherpersonaldetails({ onOtherPersonalDetails }) {

    const [formValues, setFormValues] = useState([{
        heading: 'Other personal details', dob: '', gender: '', address: '', city: '',
        country: '', pincode: '', nationality: '', maritalStatus: ''
    }]);



    let handleChange = (i, e) => {
        let newFormValues = [...formValues];
        newFormValues[i][e.target.name] = e.target.value;
        setFormValues(newFormValues);
        onOtherPersonalDetails(newFormValues)
    }

    let handleSubmit = async (event) => {
        event.preventDefault();
        let token = Cookies.get('userAuth')
        try {
            const response = await axios.post(apiUrl() + '/submit-resume',
                { OtherPersonaldetails: formValues },
                { headers: { 'Authorization': `Bearer ${token}` } })
            if (response.data.statusCode == "200") {

            }
            else {

            }

        } catch (error) {

        }
    }
    useEffect(() => {
        let x = localStorage.getItem("OTPD" + jwtVerify("userAuth").userId);
        if (x != null) {
            x = JSON.parse(x);
            setFormValues(x)
        } else {
            let usertoken = Cookies.get('userAuth')
            getUserOtherPSData(usertoken);
        }
    }, [])

    const getUserOtherPSData = (usertoken) => {
        return axios.get(apiUrl() + `/get-users-other-ps-details`, { headers: { 'Authorization': `Bearer ${usertoken}` } })
            .then(response => {

                if (response.data.statusCode == "200") {
                    setFormValues(response.data.userOtherPSData);
                } else {

                }
            })
            .catch(error => {

            });
    };

    return (
        <>
            <form onSubmit={handleSubmit} className="">
                {formValues.map((element, index) => (

                    <div className="form-inline" key={index}>
                        <section style={{ marginBottom: '10px' }} className="flex flex-col gap-3 rounded-md bg-white p-6 pt-4 shadow transition-opacity duration-200 transition-opacity duration-200 pb-6">
                            <div className="flex items-center justify-between gap-4">
                                <div className="flex grow items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg"
                                    fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor"
                                    aria-hidden="true" className="h-6 w-6 text-gray-600">
                                    <path strokeLinecap="round" strokeLinejoin="round"
                                        d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21">
                                    </path>
                                </svg>
                                    <input className="block w-full border-b border-transparent text-lg font-semibold tracking-wide text-gray-900 outline-none hover:border-gray-300 hover:shadow-sm focus:border-gray-300 focus:shadow-sm"
                                        type="text" name="heading" value={element.heading} onChange={e => handleChange(index, e)}

                                    />
                                </div>

                            </div>
                            <div className="grid overflow-hidden transition-all duration-300 visible"
                                style={{ gridTemplateRows: "1fr" }}>
                                <div className="min-h-0">
                                    <div className="row">
                                        <label className="text-base font-medium text-gray-700 col-span-full">Date of Birth
                                            <input className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base"
                                                type="date"
                                                placeholder="dd-mm-yyyy"
                                                min="1997-01-01" max="2030-12-31"
                                                name="dob" value={element.dob} onChange={e => handleChange(index, e)} />
                                        </label>
                                        <label className="text-base font-medium text-gray-700 col-span-full mt-3">Gender</label>
                                        <div className="custom-radio">

                                            <input onChange={e => handleChange(index, e)} type="radio" id="radio1" name="gender" value="Male" className='gap-3' />
                                            <label htmlFor="radio1">Male</label>


                                            <input onChange={e => handleChange(index, e)} type="radio" id="radio2" name="gender" value="Female" className='gap-3' />
                                            <label htmlFor="radio2">Female</label>

                                            <input onChange={e => handleChange(index, e)} type="radio" id="radio3" name="gender" value="Transgender" className='gap-3' />
                                            <label htmlFor="radio3">Transgender</label>

                                        </div>
                                        <label className="text-base font-medium text-gray-700 col-span-full mt-3">Address
                                            <input placeholder="Address"
                                                className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base"
                                                type="text"
                                                name="address" value={element.address || ""} onChange={e => handleChange(index, e)}
                                            />
                                        </label>
                                        <label className="text-base font-medium text-gray-700 col-span-3 mt-3">City
                                            <input placeholder="City"
                                                className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base"
                                                type="text"
                                                name="city" value={element.city || ""} onChange={e => handleChange(index, e)}
                                            />
                                        </label>
                                        <label className="text-base font-medium text-gray-700 col-span-3 mt-3">Country
                                            <input placeholder="Country"
                                                className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base"
                                                type="text"
                                                name="country" value={element.country || ""} onChange={e => handleChange(index, e)}
                                            />
                                        </label>
                                        <label className="text-base font-medium text-gray-700 col-span-3 mt-3">Pin code
                                            <input placeholder="Pin code"
                                                className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base"
                                                type="text"
                                                name="pincode" value={element.pincode || ""} onChange={e => handleChange(index, e)}
                                            />
                                        </label>
                                        <label className="text-base font-medium text-gray-700 col-span-3 mt-3">Nationality
                                            <input placeholder="nationality"
                                                className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base"
                                                type="text"
                                                name="nationality" value={element.nationality || ""} onChange={e => handleChange(index, e)}
                                            />
                                        </label>
                                        <label className="text-base font-medium text-gray-700 col-span-full mt-3">Marital Status</label>
                                        <div className='col-sm-12'>
                                            <div className="row custom-radio">

                                                <input value="Single/unmarried" onChange={e => handleChange(index, e)} type="radio" id="unmarried" name="maritalStatus" />
                                                <label className='col-sm-3' htmlFor="unmarried">Unmarried</label>


                                                <input value="Married" onChange={e => handleChange(index, e)} type="radio" id="Married" name="maritalStatus" />
                                                <label className='col-sm-3' htmlFor="Married">Married</label>

                                                <input value="Widowed" onChange={e => handleChange(index, e)} type="radio" id="Widowed" name="maritalStatus" />
                                                <label className='col-sm-3' htmlFor="Widowed">Widowed</label>

                                                <input value="Divorced" onChange={e => handleChange(index, e)} type="radio" id="Divorced" name="maritalStatus" />
                                                <label className='col-sm-3' htmlFor="Divorced">Divorced</label>


                                                <input value="Other" onChange={e => handleChange(index, e)} type="radio" id="Other" name="maritalStatus" className='gap-3' />
                                                <label className='col-sm-3' htmlFor="Other">Other</label>




                                            </div>
                                        </div>




                                    </div>
                                </div>
                            </div>


                        </section>
                    </div>
                ))}

                <div className="mt-2 flex justify-end">
                    <button
                        type="submit"
                        onClick={handleSubmit}
                        className="btn-space flex items-center rounded-md bg-white py-2 pl-3 pr-4 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50"><svg
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            strokeWidth="1.5" stroke="currentColor" aria-hidden="true"
                            className="-ml-0.5 mr-1.5 h-5 w-5 text-gray-400">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m6-6H6"></path>
                        </svg>Save</button>
                </div>
            </form>


        </>
    )
}
