import { useState, useEffect } from "react";
import axios from "axios";
import Cookies from 'js-cookie';
import { apiUrl, jwtVerify } from '../../function';
import "../css/project.css";

export default function Project({ onProjectChange }) {
    const [formValues, setFormValues] = useState([{ heading: 'PROJECT', projectName: '', projectRole: '', projectDesc: '', year: '', clientCollege: '', ManagerGuide: '' }]);
    const [year, setYear] = useState('')
    let handleChange = (i, e) => {
        let newFormValues = [...formValues];

        newFormValues[i][e.target.name] = e.target.value;
        setFormValues(newFormValues);
    }

    let addFormFields = () => {
        setFormValues([...formValues, { heading: '', projectName: '', projectRole: '', projectDesc: '', year: '', clientCollege: '', ManagerGuide: '' }])
    }

    let removeFormFields = (i) => {
        let newFormValues = [...formValues];
        newFormValues.splice(i, 1);
        setFormValues(newFormValues)
        onProjectChange(newFormValues);
    }

    let handleSubmit = async (event) => {

        event.preventDefault();
        onProjectChange(formValues);
        let token = Cookies.get('userAuth')
        try {
            const response = await axios.post(apiUrl() + '/submit-resume',
                { Project: formValues },
                { headers: { 'Authorization': `Bearer ${token}` } })
            if (response.data.statusCode === "200") {

            } else {

            }

        } catch (error) {

        }
    }
    async function getYM() {
        try {
            let response = await axios.get(apiUrl() + '/get-YM');
            let yearOption = response.data.Iyear.map((item, index) => {
                return <option key={index}>{item.year}</option>
            })
            setYear(yearOption)

        } catch (error) {
            console.error(error);
        }
    }
    useEffect(() => {
        getYM()
        let x = localStorage.getItem("PRJ" + jwtVerify("userAuth").userId);
        if (x != null) {
            x = JSON.parse(x);
            setFormValues(x)
            onProjectChange(x);
        }
        else {

            let usertoken = Cookies.get('userAuth')
            getUserProjects(usertoken);
        }
    }, [])

    const getUserProjects = (usertoken) => {
        return axios.get(apiUrl() + `/get-users-project-detail`, { headers: { 'Authorization': `Bearer ${usertoken}` } })
            .then(response => {

                if (response.data.statusCode == "200") {
                    setFormValues(response.data.userProjectData);
                } else {

                }
            })
            .catch(error => {

            });
    };

    return (
        <>
            <form onSubmit={handleSubmit} className="">
                {formValues.map((element, index) => (
                    <div className="form-inline" key={index}>
                        <section style={{ marginBottom: '10px' }} className="flex flex-col gap-3 rounded-md bg-white p-6 pt-4 shadow transition-opacity duration-200 transition-opacity duration-200 pb-6">
                            <div className="flex items-center justify-between gap-4">
                                <div className="flex grow items-center gap-2">
                                    <svg xmlns="http://www.w3.org/2000/svg"
                                        fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor"
                                        aria-hidden="true" className="h-6 w-6 text-gray-600">
                                        <path strokeLinecap="round" strokeLinejoin="round"
                                            d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21">
                                        </path>
                                    </svg>
                                    <input
                                        className="block w-full border-b border-transparent text-lg font-semibold tracking-wide text-gray-900 outline-none hover:border-gray-300 hover:shadow-sm focus:border-gray-300 focus:shadow-sm"
                                        type="text"
                                        name="heading" value={element.heading || ''} onChange={e => handleChange(index, e)}
                                    />
                                </div>
                            </div>
                            <div className="grid overflow-hidden transition-all duration-300 visible"
                                style={{ gridTemplateRows: "1fr" }}>
                                <div className="min-h-0">
                                    <div className="relative grid grid-cols-6 gap-3">
                                        <label className="text-base font-medium text-gray-700 col-span-full">Project
                                            <input className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base"
                                                type="text"
                                                placeholder="project Name"
                                                name="projectName" value={element.projectName || ""} onChange={e => handleChange(index, e)} />
                                        </label>
                                        <label
                                            className="text-base font-medium text-gray-700 col-span-full">Role
                                            <input
                                                placeholder="Software Engineer"
                                                className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base"
                                                type="text"
                                                name="projectRole" value={element.projectRole || ""} onChange={e => handleChange(index, e)}
                                            />
                                        </label>
                                        <label
                                            className="text-base font-medium text-gray-700 col-span-full">Description
                                            <textarea
                                                placeholder="Description"
                                                className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base"
                                                type="text" style={{ height: "88px" }}
                                                name="projectDesc" value={element.projectDesc || ""} onChange={e => handleChange(index, e)}
                                            ></textarea>
                                        </label>
                                        <label className="text-base font-medium text-gray-700 col-span-3">Year
                                            <select className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base"
                                                name="year" value={element.year || ""} onChange={e => handleChange(index, e)} >
                                                <option>Year</option>
                                                {year}
                                            </select>
                                        </label>
                                        <label className="text-base font-medium text-gray-700 col-span-3">Client/College
                                            <input className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base"
                                                type="text"
                                                placeholder="Client/College"
                                                name="clientCollege" value={element.clientCollege || ""} onChange={e => handleChange(index, e)} />
                                        </label>
                                        <label className="text-base font-medium text-gray-700 col-span-full">Manager/Guide(Optional)
                                            <input className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base"
                                                type="text"
                                                placeholder="Manager/Guide(Optional)"
                                                name="ManagerGuide" value={element.ManagerGuide || ""} onChange={e => handleChange(index, e)} />
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div className="mt-2 flex justify-end">
                            </div>
                        </section>
                        <div className="mt-2 flex justify-end">
                            {index ?
                                <button type="button" onClick={() => removeFormFields(index)}><i class="bi bi-trash3-fill"></i></button>
                                : null
                            }
                        </div>
                    </div>
                ))}
                <div className="mt-2 flex justify-end">
                    <button
                        type="submit"
                        className="btn-space  flex items-center rounded-md bg-white py-2 pl-3 pr-4 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50"><svg
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            strokeWidth="1.5" stroke="currentColor" aria-hidden="true"
                            className="-ml-0.5 mr-1.5 h-5 w-5 text-gray-400">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m6-6H6"></path>
                        </svg>Save</button>
                    <button type="button"
                        onClick={() => addFormFields()}
                        className="flex items-center rounded-md bg-white py-2 pl-3 pr-4 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50"><svg
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            strokeWidth="1.5" stroke="currentColor" aria-hidden="true"
                            className="-ml-0.5 mr-1.5 h-5 w-5 text-gray-400">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m6-6H6"></path>
                        </svg>Add Project</button>
                </div>
            </form>
        </>
    )
}
