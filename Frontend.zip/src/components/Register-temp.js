import "../css/Register.css";
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { apiUrl, setCreditPoints } from "../function";
import Cookies from "js-cookie";
import { useNavigate } from "react-router-dom";
import TextField from '@mui/material/TextField';
import FormControl from '@mui/material/FormControl';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import Input from '@mui/material/Input';
import IconButton from '@mui/material/IconButton';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import Button from '@mui/material/Button';

export default function Register() {

  const [showPassword, setShowPassword] = React.useState(false);

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const navigate = useNavigate();
  useEffect(() => {
    if (Cookies.get('userAuth') != undefined) {
      navigate(`/`, { replace: true });
    }
  }, [])
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [msg, setMsg] = useState('')
  const handlenameChange = (e) => {
    setName(e.target.value);

  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };


  // Function to handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (name != '' && email != '' && password != '') {
      try {
        const response = await axios.post(apiUrl() + '/register', {
          name,
          email,
          picture: '',
          password
        })
        if (response.data.statusCode == "200") {
          Cookies.set('userAuth', response.data.token.token, { expires: 365 });

          window.location.reload();
        }
        else {
          setMsg(response.data.status)
        }

      } catch (error) {
        console.error(error);
      }
    }
    else {
      setMsg('All field required !')
    }

  };

  return (
    <div>
      <div className="register">
        <div className="register-container">
          <h1 className="main-headline">SIGN UP</h1>
          <h2 className="sub-headline"> Create a FREE Account to Download your Document </h2>

          <form onSubmit={handleSubmit} >

            <TextField sx={{ mb: 1, width: '25ch' }} id="standard-basic" label="Full Name" name="name" variant="standard" value={name} onChange={handlenameChange} />
            <TextField sx={{ mb: 1, width: '25ch' }} id="standard-basic" label="Email" name="email" variant="standard" value={email} onChange={handleEmailChange} />
            <FormControl sx={{ mb: 1, width: '25ch' }} variant="standard">
              <InputLabel htmlFor="standard-adornment-password">Password</InputLabel>
              <Input
                id="standard-adornment-password"
                name="password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={handlePasswordChange}
                endAdornment={
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowPassword}
                      onMouseDown={handleMouseDownPassword}
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                }
              />
            </FormControl><br></br>
            <span className="text-danger">{msg}</span><br></br>
            <Button type="submit" variant="contained" style={{ padding: "10px", width: "25ch" }}>Register</Button>
            {/* <input type="text" placeholder="Full Name" value={name} onChange={handlenameChange} />
                        <input type="email" placeholder="Enter Email" value={email} onChange={handleEmailChange} />
                        <input type="password" placeholder="Enter Password" value={password} onChange={handlePasswordChange} />
                        <span className="text-danger">{msg}</span>
                        <button type="submit">Register</button> */}
          </form>
        </div>
      </div>



    </div>

  );
}
