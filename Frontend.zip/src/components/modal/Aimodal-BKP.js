import { useEffect, useState } from "react";
import { getCreditPoint, deductCreditPoints, getCreditPointDeducts } from "../../function";
import { Modal } from 'react-responsive-modal';
import LoaderComp from '../form/LoaderComp';
import Cookies from "js-cookie";
function Aisuggesstionmodal(props) {
    const [creditPoints, setCreditPoints] = useState(null);
    const [creditPointsDeduct, setCreditPointsDeduct] = useState(null);


    useEffect(() => {
        // API call for getCreditPoint ---------getCreditPointDeduct-------------
        getCreditP();
        getCreditPointDeduct();
    }, []);

    const getCreditP = async () => {
        let token = Cookies.get('userAuth')
        let creditPT = await getCreditPoint(token);
        if (creditPT) {
            setCreditPoints(creditPT);
        }

    }

    const getCreditPointDeduct = async () => {
        let creditPointDeduct = await getCreditPointDeducts();
        if (creditPointDeduct) {
            setCreditPointsDeduct(creditPointDeduct);
        }
    }

    console.log('AI -- getCreditPointDeduct', creditPointsDeduct);
    //  console.log('AI -- getCreditP', creditPointsDeduct);


    const deductCreditPts = async (value) => {
        console.log('--inside AI modal-- creditPointsDeduct', value);
        let token = Cookies.get('userAuth')
        if (creditPoints >= value) {
            let availCreditPoints = creditPoints - value;
            console.log('---AI Moadl - ', availCreditPoints);
            let updateCP = await deductCreditPoints(availCreditPoints, token);
            console.log('--AI-updateCP---', updateCP);
            setCreditPoints(availCreditPoints);
            getCreditP();
        }
        else if (creditPoints == 0) {
            setCreditPoints(0);
        }
    };
    return (
        <>
            {props.isLoading ? (<Modal open={props.open} onClose={props.closeModal} showCloseIcon='false' closeIcon=' ' classNames={{
                overlayAnimationIn: 'customEnterOverlayAnimation',
                overlayAnimationOut: 'customLeaveOverlayAnimation',
                modalAnimationIn: 'customEnterModalAnimation',
                modalAnimationOut: 'customLeaveModalAnimation',
            }}
                animationDuration={800}
                center ><LoaderComp /></Modal>) : <>
                {props.aiSuggesstion && (
                    <Modal open={props.open} onClose={props.closeModal} classNames={{
                        overlayAnimationIn: 'customEnterOverlayAnimation',
                        overlayAnimationOut: 'customLeaveOverlayAnimation',
                        modalAnimationIn: 'customEnterModalAnimation',
                        modalAnimationOut: 'customLeaveModalAnimation',
                    }}
                        animationDuration={800}
                        center >
                        {props.aiSuggesstion != undefined ? (<div style={{ top: '15px', position: 'relative' }}>
                            {Object.entries(props.aiSuggesstion).map(([key, value]) => (
                                <button key={key} value={value.replace("\n\n", "")} onClick={(e) => {
                                    props.handlechangeAitext(e);
                                    props.closeModal()
                                    deductCreditPts(creditPointsDeduct);
                                }} name={props.for} className="phrases">{value}</button>
                            ))}
                        </div>) : ''}
                    </Modal>
                )}
            </>}
        </>
    )

}

export { Aisuggesstionmodal }