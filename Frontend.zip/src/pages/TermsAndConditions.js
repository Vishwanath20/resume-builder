import TAC from "../components/form/TAC";

export default function TermsandConditons(){
    return(
        <TAC></TAC>
    )
}