import PP from "../components/form/PP";

export default function PrivacyPolicy(){
    return(
        <PP></PP>
    )
}