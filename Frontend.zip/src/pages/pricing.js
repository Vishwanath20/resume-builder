import PricingSection from "../components/pricing";

export default function Pricing() {
  return (
    <PricingSection></PricingSection>


  )
}