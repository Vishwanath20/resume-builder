-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: resumbebuilder.cp6ut16gcm0c.ap-south-1.rds.amazonaws.com
-- Generation Time: Feb 22, 2024 at 05:51 PM
-- Server version: 8.0.35
-- PHP Version: 8.1.2-1ubuntu2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_magic_point`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int NOT NULL,
  `admin_user_name` varchar(50) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_password` varchar(50) NOT NULL,
  `admin_type` int NOT NULL,
  `token` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_user_name`, `admin_email`, `admin_password`, `admin_type`, `token`) VALUES
(3, 'vikah', 'vikashrakesh200@gmailcom', '123', 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMsIm5hbWUiOiJ2aWthaCIsInR5cGUiOiIxIiwiaWF0IjoxNzAwNzM4NzM2fQ.OAtUIj8mK6Dzxh6jM_gSEBM7m5b-FOOylkEVmi9GIz8');

-- --------------------------------------------------------

--
-- Table structure for table `admin_super`
--

CREATE TABLE `admin_super` (
  `super_admin_id` int NOT NULL,
  `super_admin_user_name` varchar(50) NOT NULL,
  `super_admin_email` varchar(50) NOT NULL,
  `super_admin_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `certification`
--

CREATE TABLE `certification` (
  `certificate_id` int NOT NULL,
  `user_id` int NOT NULL,
  `certificationCourse` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `certificateID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `CertificateVerificationURL` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `issueDateMonth` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `issueDateYear` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `expiryDateMonth` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `expiryDateYear` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `certification`
--

INSERT INTO `certification` (`certificate_id`, `user_id`, `certificationCourse`, `certificateID`, `CertificateVerificationURL`, `issueDateMonth`, `issueDateYear`, `expiryDateMonth`, `expiryDateYear`) VALUES
(124, 157, 'Certficat123', 'cer256', 'sss.ggoog.com', 'Feb', '2021', 'Mar', '2021'),
(125, 157, 'Certficat123', 'cer256', 'sss.ggoog.com', 'Feb', '2021', 'Mar', '2021'),
(126, 157, 'Certficat123', 'cer256', 'sss.ggoog.com', 'Feb', '2021', 'Mar', '2021'),
(127, 157, 'dddddd', 'dddddd', 'ddddddd2222222222222222', 'Feb', '2017', 'Oct', '2017'),
(128, 157, 'dddddd', 'dddddd', 'ddddddd', 'Feb', '2017', 'Oct', '2017'),
(132, 158, 'cccc', 'cccccc', 'ccccc', 'Jan', '2015', 'Oct', '2013'),
(133, 158, 'ccccccc111111111111', 'cccccccc', 'ccccccc', 'Feb', '2016', 'Oct', '2019'),
(135, 171, 'aaaaaaaaa', 'aaaaaaaa', 'aaaaaaaa', 'Dec', '2017', 'May', '2019'),
(136, 171, 'ssssssss', 'ssssssss', 'ssssssss', 'Dec', '2019', 'Jan', '2023');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us_db`
--

CREATE TABLE `contact_us_db` (
  `contact_us_id` int NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `subject` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `message` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_us_db`
--

INSERT INTO `contact_us_db` (`contact_us_id`, `name`, `email`, `subject`, `message`, `created_on`) VALUES
(3, 'vikash rakesh', 'vikashrakesh200@gmai', 'subject demo', 'demo message', '0000-00-00 00:00:00'),
(4, 'vikash rakesh', 'vikashrakesh200@gmai', 'hjh', 'jhjhjhj', '0000-00-00 00:00:00'),
(5, 'vikash rakesh', 'vikashrakesh200@gmai', 'subject demo', 'ghghhg', '0000-00-00 00:00:00'),
(6, 'Shailendra', 'shailendra@newtumcom', 'Hello', 'Hello How are you', '0000-00-00 00:00:00'),
(7, 'Shailendra', 'shailendra@newtumcom', 'Hello', 'Hello How are you', '0000-00-00 00:00:00'),
(8, 'Shailendra', 'shailendra@newtumcom', 'Hello', 'Hello How are you', '0000-00-00 00:00:00'),
(9, 'Shailendra', 'shailendra@newtumcom', 'adsfasdf', 'adsasdfasdf', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int NOT NULL,
  `course_name` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`) VALUES
(1, 'BA'),
(2, 'BSc'),
(3, 'BCom'),
(4, 'BE'),
(5, 'B.Tech'),
(6, 'BBA'),
(7, 'BCA'),
(8, 'MBBS'),
(9, 'BDS'),
(10, 'BPharm'),
(11, 'MA'),
(12, 'MSc'),
(13, 'MCom'),
(14, 'MBA'),
(15, 'MCA'),
(16, 'ME'),
(17, 'M.Tech'),
(18, 'MSW'),
(19, 'MPA'),
(20, 'MPharm'),
(21, 'Ph.D.'),
(22, 'MD'),
(23, 'DDS'),
(24, 'DSc'),
(25, 'DBA'),
(26, 'CA'),
(27, 'CS'),
(28, 'CMA'),
(29, 'B.Ed');

-- --------------------------------------------------------

--
-- Table structure for table `cover_letter`
--

CREATE TABLE `cover_letter` (
  `cover_letter_id` int NOT NULL,
  `user_id` int NOT NULL,
  `cover_letter` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `credit_point`
--

CREATE TABLE `credit_point` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `credit_point` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `credit_point`
--

INSERT INTO `credit_point` (`id`, `user_id`, `credit_point`) VALUES
(83, 157, 0),
(84, 158, 10),
(85, 159, 50),
(86, 160, 50),
(87, 161, 50),
(88, 162, 50),
(89, 163, 50),
(90, 164, 50),
(91, 167, 50),
(92, 168, 50),
(93, 169, 45),
(94, 170, 40),
(95, 171, 45),
(96, 172, 35),
(97, 173, 50),
(98, 174, 0),
(99, 175, 48600),
(100, 176, 60),
(101, 177, 60),
(102, 178, 60),
(103, 179, 60),
(104, 180, 42895),
(105, 182, 660),
(106, 183, 60),
(107, 184, 0),
(108, 185, 45),
(109, 186, 50);

-- --------------------------------------------------------

--
-- Table structure for table `custom_section`
--

CREATE TABLE `custom_section` (
  `custom_section_id` int NOT NULL,
  `user_id` int NOT NULL,
  `heading` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `activityName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `descp` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `custom_section`
--

INSERT INTO `custom_section` (`custom_section_id`, `user_id`, `heading`, `activityName`, `descp`) VALUES
(28, 150, 'Heading Here1', 'xyz', 'descp3'),
(29, 158, 'Heading Here', 'xxxxxxx', 'xxxxxxxx'),
(30, 158, 'Heading Here', '', 'xxxxxxxxx');

-- --------------------------------------------------------

--
-- Table structure for table `default_credit_point`
--

CREATE TABLE `default_credit_point` (
  `credit_point_id` int NOT NULL,
  `credit_points` int NOT NULL,
  `credit_points_deduct` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `default_credit_point`
--

INSERT INTO `default_credit_point` (`credit_point_id`, `credit_points`, `credit_points_deduct`) VALUES
(4, 50, 5);

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE `education` (
  `education_id` int NOT NULL,
  `user_Id` int NOT NULL,
  `school` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `courseName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `specialization` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `date` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `gradingSystem` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `markes` int NOT NULL,
  `courseType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `descp` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`education_id`, `user_Id`, `school`, `courseName`, `specialization`, `date`, `gradingSystem`, `markes`, `courseType`, `descp`) VALUES
(75, 157, 'GECR', 'MA', '', '2018', 'Scale 4 Grading System', 33, 'Part Time', 'qqqqqqqqqqqqqqqqqq'),
(76, 157, 'GECR-222qqq', 'B.Tech', '', '2007', '% Marks of 100 Maximum', 55, 'Full Time', 'gggggggggggg111111111222222222'),
(81, 158, 'GECR', 'B.Tech', '', '2016', 'Scale 4 Grading System', 22, 'Correspondence', '222222222222222222222222222'),
(82, 158, 'SSM', 'MCA', '', '2020', 'Scale 4 Grading System', 55, 'Part Time', 'ssssssssssssssssss'),
(83, 163, 'eeeeee', 'MBA', '', '', '', 0, '', 'eeeeeeee'),
(93, 170, '', '', '', '', '', 0, '', ''),
(94, 170, '', '', '', '', '', 0, '', ''),
(95, 170, '', '', '', '', '', 0, '', ''),
(96, 170, '', '', '', '', '', 0, '', ''),
(97, 170, '', '', '', '', '', 0, '', ''),
(114, 171, 'sssss', 'MSc', '', '2020', 'Scale 4 Grading System', 22, 'Full Time', 'sssssssssssssss'),
(115, 171, 'eeee32222222', 'MCom', 'Data Analysis', '2007', 'Scale 4 Grading System', 22, 'Full Time', 'eeeeeeeeeeeeeeee'),
(118, 184, 'CSS', 'BBA', '', '2019', 'Scale 4 Grading System', 44, 'Part Time', 'I havkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk'),
(119, 184, 'dddddddd', '', '', '', '', 22, 'Part Time', 'dddddddddddddddddddd');

-- --------------------------------------------------------

--
-- Table structure for table `email_verification`
--

CREATE TABLE `email_verification` (
  `ID` int NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `token` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `email_verification`
--

INSERT INTO `email_verification` (`ID`, `user_email`, `token`) VALUES
(1, 'visupater@gmail.com', 'gfqt5hrsi8ha0mq85fj29ggrg315mq6pi8v');

-- --------------------------------------------------------

--
-- Table structure for table `extra_curricular_activities`
--

CREATE TABLE `extra_curricular_activities` (
  `extra_curricular_activities_id` int NOT NULL,
  `user_id` int NOT NULL,
  `activityName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `descp` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `extra_curricular_activities`
--

INSERT INTO `extra_curricular_activities` (`extra_curricular_activities_id`, `user_id`, `activityName`, `descp`) VALUES
(17, 157, 'ssssssss', 'sssssssssssss'),
(21, 158, 'aaaaaaaaa', 'aaaaaaaaaaa'),
(22, 158, 'xxxxxxx', 'xxxxx');

-- --------------------------------------------------------

--
-- Table structure for table `grading_system`
--

CREATE TABLE `grading_system` (
  `grading_system_id` int NOT NULL,
  `grading_name` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hobbies`
--

CREATE TABLE `hobbies` (
  `hobbies_id` int NOT NULL,
  `user_id` int NOT NULL,
  `hobbies` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hobbies`
--

INSERT INTO `hobbies` (`hobbies_id`, `user_id`, `hobbies`) VALUES
(17, 157, 'sssssssssssss'),
(18, 157, 'sssssssssssss'),
(19, 157, 'sssssssssssssaaaaaaaaa'),
(20, 157, 'sssssssssssss'),
(22, 158, 'sssssssssss');

-- --------------------------------------------------------

--
-- Table structure for table `int_str_month`
--

CREATE TABLE `int_str_month` (
  `int_str_month_id` int NOT NULL,
  `month` varchar(20) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `int_str_month`
--

INSERT INTO `int_str_month` (`int_str_month_id`, `month`) VALUES
(1, '1 Month'),
(2, '2 Month'),
(3, '3 Month'),
(4, '4 Month'),
(5, '5 Month'),
(6, '6 Month'),
(7, '7 Month'),
(8, '8 Month'),
(9, '9 Month'),
(10, '10 Month'),
(11, '11 Month'),
(12, '12 Month');

-- --------------------------------------------------------

--
-- Table structure for table `int_str_year`
--

CREATE TABLE `int_str_year` (
  `int_str_year_id` int NOT NULL,
  `year` varchar(20) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `int_str_year`
--

INSERT INTO `int_str_year` (`int_str_year_id`, `year`) VALUES
(1, '1 year'),
(2, '2 years'),
(3, '3 years'),
(4, '4 years'),
(5, '5 years'),
(6, '6 years'),
(7, '7 years'),
(8, '8 years'),
(9, '9 years'),
(10, '10 years'),
(11, '11 years'),
(12, '12 years'),
(13, '13 years'),
(14, '14 years'),
(15, '15 years'),
(16, '16 years'),
(17, '17 years'),
(18, '18 years'),
(19, '19 years'),
(20, '20 years'),
(21, '21 years'),
(22, '22 years'),
(23, '23 years'),
(24, '24 years'),
(25, '25 years'),
(26, '26 years'),
(27, '27 years'),
(28, '28 years'),
(29, '29 years'),
(30, '30 years');

-- --------------------------------------------------------

--
-- Table structure for table `int_year_master`
--

CREATE TABLE `int_year_master` (
  `int_year_id` int NOT NULL,
  `year` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `int_year_master`
--

INSERT INTO `int_year_master` (`int_year_id`, `year`) VALUES
(17, 2006),
(18, 2007),
(19, 2008),
(20, 2009),
(21, 2010),
(22, 2011),
(23, 2012),
(24, 2013),
(25, 2014),
(26, 2015),
(27, 2016),
(28, 2017),
(29, 2018),
(30, 2019),
(31, 2020),
(32, 2021),
(33, 2022),
(34, 2023),
(35, 2012),
(36, 2012),
(37, 2022),
(38, 2023),
(39, 2029),
(40, 3021),
(41, 4001),
(43, 20061);

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE `language` (
  `language_id` int NOT NULL,
  `user_id` int NOT NULL,
  `language` varchar(300) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`language_id`, `user_id`, `language`) VALUES
(22, 157, 'aaaaaaa'),
(31, 158, 'sssssss'),
(32, 158, 'wwwwwwwwwwwww'),
(33, 175, '');

-- --------------------------------------------------------

--
-- Table structure for table `other_personal_details`
--

CREATE TABLE `other_personal_details` (
  `other_personal_details_id` int NOT NULL,
  `User_id` int NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `address` varchar(300) COLLATE utf8mb4_general_ci NOT NULL,
  `city` varchar(300) COLLATE utf8mb4_general_ci NOT NULL,
  `pincode` int NOT NULL,
  `country` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `nationality` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `maritalStatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `other_personal_details`
--

INSERT INTO `other_personal_details` (`other_personal_details_id`, `User_id`, `dob`, `gender`, `address`, `city`, `pincode`, `country`, `nationality`, `maritalStatus`) VALUES
(38, 157, '2023-12-14', 'Male', 'sssssssss', 'ssssss', 11111, 'sssssssssss', 'ssssssssssssssssssss', 'Other'),
(39, 157, '2023-12-14', 'Male', 'sssssssss', 'ssssss', 11111, 'sssssssssss', '', 'Married'),
(41, 158, '2023-12-08', 'Male', 'aaaaaaaa', 'aaaaaaaa', 0, 'asssssssss', 'ssssssssss', 'Single/unmarried');

-- --------------------------------------------------------

--
-- Table structure for table `package_list`
--

CREATE TABLE `package_list` (
  `package_list_id` int NOT NULL,
  `package_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `price` int NOT NULL,
  `num_of_template` int NOT NULL,
  `cover_letter` int NOT NULL,
  `credit_points` int NOT NULL,
  `credit_point_deduct` int NOT NULL,
  `premium_powerful_AI` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `water_mark` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `premium_template` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `download_option` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `email_support` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `phone_support` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `portfolio` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `custom_domain` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `package_type` int NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `package_list`
--

INSERT INTO `package_list` (`package_list_id`, `package_name`, `price`, `num_of_template`, `cover_letter`, `credit_points`, `credit_point_deduct`, `premium_powerful_AI`, `water_mark`, `premium_template`, `download_option`, `email_support`, `phone_support`, `portfolio`, `custom_domain`, `package_type`, `image`) VALUES
(10, 'Free', 0, 5, 3, 50, 0, 'No', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 0, 'pricing-free.png'),
(11, 'Starters', 149, 10, 50, 600, 0, 'No', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 1, 'pricing-starter.png'),
(12, 'Experts', 299, 0, 500, 6000, 0, 'No', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 1, 'pricing-experts.png'),
(13, 'Professionals', 599, 0, 500, 6000, 0, 'No', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 1, 'pricing-professional.png'),
(15, 'Demopack', 200, 20, 20, 6000, 5, 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'No', 'No', 'No', 1, 'pricing-starter.png');

-- --------------------------------------------------------

--
-- Table structure for table `payment_summary`
--

CREATE TABLE `payment_summary` (
  `payment_summary_id` int NOT NULL,
  `user_id` int NOT NULL,
  `package_list_id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `address` varchar(300) NOT NULL,
  `city` varchar(100) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `country` varchar(50) NOT NULL,
  `pay_ammount` int NOT NULL,
  `pay_order_id` varchar(300) NOT NULL,
  `payment_id` varchar(300) NOT NULL,
  `payment_status` varchar(100) NOT NULL,
  `razorpay_signature` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `payment_summary`
--

INSERT INTO `payment_summary` (`payment_summary_id`, `user_id`, `package_list_id`, `name`, `email`, `phone`, `address`, `city`, `pincode`, `country`, `pay_ammount`, `pay_order_id`, `payment_id`, `payment_status`, `razorpay_signature`) VALUES
(36, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFNwsGtY2pkcO6', 'pay_NFNxDlvy3eZB0U', 'Success', '620aa89263aa4fd09571099389bd13fccf4abbf750d05afaa1a39b3eab46663b'),
(37, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFO0EgR4o3SGTl', 'pay_NFO0TnFvfMssJg', 'Failed', 'undefined'),
(38, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFOEw2Mvsofz0Y', 'pay_NFOFEiPTymW0hd', 'Success', 'e26da7232b434570c39109467d1ab2b47b69ec71f6cef4d93646d43e7137b157'),
(39, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFOULdt3N9gmaY', '', '', ''),
(40, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFP5U3d9BmyfP9', 'pay_NFP5rCTJw1hp4R', 'Success', 'aaa7f97b08acb5c3af9ca237bbb15e16dbba3b3f500caf2d72119367146b35f0'),
(41, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFPHnqs3rRVkH0', 'pay_NFPI4jY86P1PSf', 'Success', 'a8404a238d99ee60a8d325260818f23511acc7a165c227c3ff36bc58f7ca053b'),
(42, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFPJk4kShhgo77', 'pay_NFPK8fkPwUFDk2', 'Success', '7b358251013bdfb2b67291a4a1beb844a50a1865e50d535f45771512cc5caf9b'),
(43, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFPSvos97Tocnu', 'pay_NFPTAdqIhhLzCK', 'Success', 'b10aa1a5d331e7fd87ebbfd9fe3548a9d3218047545570da31fbac9731cd2da9'),
(44, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFPpc4RwsCGbPC', 'pay_NFPpuVEInHsG7e', 'Success', 'e1af326cfc2c7d3f4f6ea20e04c5e1ade338f7328a62c6118fe024e92b37f7d9'),
(45, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFPsQq0SQZwiFy', 'pay_NFPsij7QDBr5fW', 'Failed', 'undefined'),
(46, 175, 13, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'AS', 599, 'order_NFQhoJlRfCbBaC', 'pay_NFQiBr5CQkE1h7', 'Success', '040e688714db7f1d09503c977837cca9cd0f2ce12bc30aa240f6e1834a23cdd2'),
(47, 175, 12, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'AS', 299, 'order_NFeXBeEmlIDv0i', 'pay_NFeYXO9I2dj4pg', 'Success', '833ddf35ae514a64ac5a67c914b3bd15765c51c0132547131f24726ad512fff1'),
(48, 175, 12, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'AS', 299, 'order_NFeaJaNRah4st2', 'pay_NFeadqQxARplP4', 'Success', '359aee8ed6cc25c4dfdb00b1447f4847ede8b8421b2ae76d01ec05ecd0a01e17'),
(49, 175, 12, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'AS', 299, 'order_NFebnjr5db5SzQ', 'pay_NFebzcgzzHBymP', 'Success', '018102ec46ab084f9e3e639a3065f405de85230de6f54ce7d5ff819e9da22a36'),
(50, 175, 13, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'AL', 599, 'order_NFedL89OT3w2TD', 'pay_NFedXhleJs1cvt', 'Success', 'fdfc1ba598f96cd5e7471a29d99dee0dee5fff4948a48ce165687ad15ca23926'),
(51, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFfC7VZ1JCesJV', 'pay_NFfCVVwCLfXl0i', 'Success', '2212851dada401114ac31f66662e61d5595a08eb40fde995b375d8b576970f48'),
(52, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFfPWoUjZR6SzO', 'pay_NFfPttpEu0jVgX', 'Success', 'd72d077f441d1d3a549ff80c6ef7b34771f74430fca75fb293232b6c8943f6c7'),
(53, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFfTk8lmumZHdT', 'pay_NFfU1j0j7UN2cf', 'Success', '94ab191f483fa8688570a2d562c1d8b49ba1b6e072464ebb497df731ef2782b1'),
(54, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFfdVh1c2xjx2w', 'pay_NFfdvMBiFPGLy7', 'Success', '7822331fb5dc6adec14c2097ab018e17e5b2515e57c8b300116cdad2d86f7321'),
(55, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFfpT0rRb5etil', 'pay_NFfpkgsQTTvW1U', 'Success', '96c83d4ad0a58199a050bd4d82bafaf1b95bf0619fa09ff69fac52a527054dee'),
(56, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFftrQpQTreksb', 'pay_NFfu6THXAmMoBy', 'Success', 'b24edcbde6366854d4b8b0e58092728bb962848a5a3f470381e474bf114b69d9'),
(57, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFfwbKkUGxa9hK', '', '', ''),
(58, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFfxEP8uugsFCA', 'pay_NFfxTYysz8KDaB', 'Success', 'bbacd062d5d6302bfae0dceb3b1c269ba4599ef95e918b0762b2244e966bbb22'),
(59, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFg1NjcnQGDTyB', 'pay_NFg1jf9rGzceVF', 'Success', '706923586fdf8a44789df375d9876ec938cf0dd4913c6274b87a9e58986db7db'),
(60, 175, 11, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 149, 'order_NFg4CazTc9QT4X', 'pay_NFg4PCTdqO2rPB', 'Success', 'd7b8610bca1734ae944d32f4fb1b5cd65978785fdf75553dde7db93865d8e597'),
(61, 175, 12, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 299, 'order_NGcJW1CB0LcwZ9', 'pay_NGcKAlU9VgO9da', 'Success', 'e5149b2a18727b7be3778bfb8562767c4813f9650bfd5dcaad5bc405ba4001ab'),
(62, 175, 12, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'AL', 299, 'order_NHHWELPwMUBEWg', 'pay_NHHX3acsCeBivQ', 'Success', '05386e9caebcf09ba6b53caad111d4c07e629a0f767956c7b122e43a96c4fb8d'),
(63, 182, 11, 'VISHWANTH KUMAR PATER', 'visupater@gmail.com', '7869235896', 'sarangarh', 'raipur', '496450', 'AF', 149, 'order_NHewwYcNSBXrU4', '', '', ''),
(64, 182, 11, 'VISHWANTH KUMAR PATER', 'visupater@gmail.com', '7869235896', 'sarangarh raipur chhat', 'raipur', '496450', 'AF', 149, 'order_NHex5EZT3D6JKU', 'pay_NHezdE0KSEx8KR', 'Success', '2943c74a938f754366542b4fe1fd60edec52b8debaa7c69d3bdb63a8f4dcbf36'),
(65, 180, 12, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 299, 'order_NJemcMWaTrvoYP', 'pay_NJenlHkatmuOdh', 'Success', 'cccc4f72f9318852304b712313b5cf28de35a52777276efefca8c10c97cbb4f3'),
(66, 180, 13, 'vikash rakesh', 'vikashrakesh200@gmail.com', '8770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 599, 'order_NJf0JgaMcTibJA', 'pay_NJf0dc14HLRkTy', 'Success', '726c8d1f71b28313db290e413e7021efdf3841ad85b8557e3c8d9072fd9d2a1f'),
(67, 180, 13, 'vikash rakesh', 'vikashrakesh200@gmail.com', '8770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 599, 'order_NJf1Kd31sl9oGw', 'pay_NJf1lkjTeaf4kg', 'Success', '9852da12804f292dafb952a47b88ae2756cbdaa5603c86afda905f2388c3dfc6'),
(68, 180, 13, 'vikash rakesh', 'vikashrakesh200@gmail.com', '8770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 599, 'order_NJf3S0l3GpObrl', 'pay_NJf3r7rkdgZuR5', 'Success', 'f4a622d0417c6f97c33d13b6b3aab95701a7022bd859ad5935c83a5f1e3f2a42'),
(69, 180, 13, 'vikash rakesh', 'vikashrakesh200@gmail.com', '8770031801', 'jashpur sarangarh', 'raigarh', '496445', 'DZ', 599, 'order_NJf664yScCO63l', 'pay_NJf6M2ZRku2t8f', 'Success', '057321733dae77e51d814aca8d27885daf6472393437440590d75976904c6e44'),
(70, 180, 13, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'AS', 599, 'order_NJf9X7JpiDuoWn', 'pay_NJf9oLk6p08N1K', 'Success', 'ea232f1452959575aedb90fb934a50593b521efbc1f7405adcd0cb071decf39e'),
(71, 180, 13, 'vikash rakesh', 'vikashrakesh200@gmail.com', '08770031801', 'jashpur sarangarh', 'raigarh', '496445', 'AS', 599, 'order_NJfALDaqHUMZPV', 'pay_NJfAa1uO3KO0GO', 'Success', 'cb926c5f79dc5c380fa4fc90f729a9930c1451959be57851c39be6d393e00a6e');

-- --------------------------------------------------------

--
-- Table structure for table `personal_details`
--

CREATE TABLE `personal_details` (
  `other_personal_details_id` int NOT NULL,
  `user_id` int NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `profile_pic` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `countryCode` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `workExperienceyear` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `workExperiencemonth` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `resumeHeadline` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `summary` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `personal_details`
--

INSERT INTO `personal_details` (`other_personal_details_id`, `user_id`, `name`, `profile_pic`, `email`, `countryCode`, `phone`, `workExperienceyear`, `workExperiencemonth`, `resumeHeadline`, `summary`) VALUES
(192, 157, 'Vishwanath kumar pater', 'Not profile photo', 'vishwanthkumarpater@gmailcom', '', '7896896589', '9 years', '3 Month', '\r\n\r\nI have extensive experience in various industries including marketing dfinance and technology My skills include project management data analysis and communication I am a quick learner and thrive in fast-paced environments I am seeking a challengi', '\r\n\r\nWith a diverse background in marketing finance and technology I possess a wide range of skills such as project management data analysis and communication My adaptability and ability to excel in fast-paced environments make me a valuable asset I am eager to take on a challenging role where I can utilize my skills to drive the growth of the company'),
(193, 149, 'Praksh', 'Not profile photo', 'prasksk@gmailcom', '', '58256325', '11 years', '7 Month', 'dddddddddddddddddddddddddddddddd', 'ddddddddddddddddd'),
(194, 158, 'Vishwanath', 'Not profile photo', 'visupater1@gmailcom', '', '7869521536', '10 years', '5 Month', '\r\n\r\nI have extensive experience in various industries including marketing finance and technology My skills include project management data analysis and communication I am a quick learner and thrive in fast-paced environments I am seeking a challengin', '\r\n\r\nI have extensive experience in various industries including marketing finance and technology My skills include project management data analysis and communication I am a quick learner and thrive in fast-paced environments I am seeking a challenging role where I can utilize my skills and contribute to the growth of the company'),
(195, 163, 'Vishwanath', 'Not profile photo', 'vishu@gmailcom', '', '5555555555', '12 years', '5 Month', 'dddddddddddddddddddddddddddddddd', 'ddddddddddddddddddddddddddddddd'),
(196, 169, 'vvvvvv', 'Not profile photo', 'vvvvvvv', '', 'vvvvvvv', '14 years', '7 Month', '\r\n\r\nI have extensive experience in various fields including project management marketing and customer service My strong communication and organizational skills have allowed me to successfully lead teams and achieve goals I am highly adaptable and thr', ''),
(197, 170, 'Shailendra', 'Not profile photo', 'admin@admincom', '', '8422996373', '14 years', '3 Month', '\r\n\r\nI am a skilled blockchain developer with a passion for creating innovative solutions My expertise lies in developing secure and efficient blockchain applications using various programming languages I have a strong understanding of blockchain tech', '\r\n\r\nI am a highly skilled blockchain developer with a strong passion for creating cutting-edge solutions My proficiency lies in developing secure and efficient blockchain applications using diverse programming languages With a deep understanding of blockchain technology and its potential to transform industries I am eager to collaborate and shape the future'),
(198, 172, 'Shailendra Bramhvanshi', 'http://localhost:4000/assest/profilePic/profilePic_1704272171242.jpg', 'shailendra.bramhvanshi@techaroha.com', 'undefined', '8422996373', '2 years', '3 Month', 'We\r\nAs a blockchain developer I have a strong understanding of distributed ledger technology and its applications I am proficient in programming languages such as Solidity and C and have experience in developing smart contracts and decentralized appl', '\r\n\r\nAs a blockchain developer I possess a deep understanding of distributed ledger technology and its practical uses My expertise lies in programming languages like Solidity and C and I have a proven track record in creating smart contracts and decentralized applications I am committed to staying updated with the ever-changing blockchain landscape to provide cutting-edge solutions'),
(204, 174, 'vikash rakesh', '', 'vikashrakesh@gmail.com', '+91', '8770031801', '15 years', '8 Month', 'hghgh', 'hghghgh'),
(205, 175, 'vikash rakesh', 'https://lh3.googleusercontent.com/a/ACg8ocK-lPIgElQq1y7EHmxxrqeVc4u3dJ7MN_OnwkyT2dIMnw=s96-c', 'vikashrakesh200@gmail.com', '', '8770031801', '', '', '', ''),
(206, 184, 'Vishwanath', '', 'visupater@gmail.com', 'undefined', '7869562358', '', '', 'I have extensive experience in various industries, including marketing, finance, and technology. My skills include project management, data analysis, and communication. I am a quick learner and thrive in fast-paced environments. I am seeking a challe', 'I have extensive experience in various industries, including marketing, finance, and technology. My skills include project management, data analysis, and communication. I am a quick learner and thrive in fast-paced environments. I am seeking a challenging role where I can utilize my skills and contribute to the growth of the company.'),
(208, 171, 'aaaaaaaaaa', '', 'aaaaaa@sssssss.xx', '', '1122334455', '1 year', '1 Month', 'sssssssssssssssssssssssssssssssssssssssssss', 'sssssssssssssssssssssssssssssssssssss');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `project_id` int NOT NULL,
  `user_id` int NOT NULL,
  `projectName` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `projectRole` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `projectDesc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `year` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `clientCollege` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `ManagerGuide` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`project_id`, `user_id`, `projectName`, `projectRole`, `projectDesc`, `year`, `clientCollege`, `ManagerGuide`) VALUES
(48, 157, 'ppppp', 'pppppppp', 'qqqqqqqqqq', '2015', 'qqqqqq', 'qqqqqqqqqqqq'),
(49, 157, 'ppppp', 'pppppppp', 'qqqqqqqqqq', '2015', 'qqqqqq', 'qqqqqqqqqqqq'),
(50, 157, 'wwwwwwwwwww', 'wwwwwwww', 'wwwwwwww', '2018', 'wwwwwwwww', 'wwwwwwwwwwwwwww1111111111111'),
(56, 158, 'qqqqqqq', 'qqqqqqq', 'qqqqqqqqqqqq', '2015', 'qqqqqq', 'qqqqqqqqqqq'),
(57, 158, 'qqqqqqq', 'qqqqqqq', 'qqqqqqqqqqqq', '2015', 'qqqqqq', 'qqqqqqqqqqq'),
(58, 158, 'xxxxxxx', 'xxxxxx', 'xxxxxxx', '2018', 'xxxxxx', 'xxxxxxxxx'),
(59, 158, 'xxxxxxx111111111111', 'xxxxxx', 'xxxxxxx', '2018', 'xxxxxx', 'xxxxxxxxx'),
(60, 171, 'ssssssssssssss', 'ssssssssss', 'ssssssssssssssssssssssssssssssss', '2019', 'ssssss', 'ssssssssss');

-- --------------------------------------------------------

--
-- Table structure for table `skill`
--

CREATE TABLE `skill` (
  `skill_id` int NOT NULL,
  `user_id` int NOT NULL,
  `skillName` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `skillRating` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `skill`
--

INSERT INTO `skill` (`skill_id`, `user_id`, `skillName`, `skillRating`) VALUES
(54, 157, 'sssssssssss', 2),
(55, 157, 'sssssssssss', 2),
(56, 157, 'cccccc', 4444),
(57, 157, 'cccccc', 4),
(63, 158, 'aaaaaaaaaqqqqqqqqq', 0),
(64, 158, 'aaaaaaaaaqqqqqqqqq', 0),
(65, 158, 'aaaaaaaaaqqqqqqqqq', 0),
(66, 158, 'ssssssssss', 0),
(67, 158, 'ssssssssssqqqqqqqqq', 0),
(70, 175, '', 0),
(71, 171, 'ssssssssssss', 1),
(72, 172, '234432345', 4);

-- --------------------------------------------------------

--
-- Table structure for table `social_link`
--

CREATE TABLE `social_link` (
  `social_link_id` int NOT NULL,
  `user_id` int NOT NULL,
  `socialLinks` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `social_link`
--

INSERT INTO `social_link` (`social_link_id`, `user_id`, `socialLinks`) VALUES
(26, 157, 'aaaaaaaaaaaaaaaqqqqqqqqqqqqqqqqqq'),
(27, 157, 'aaaaaaaaaaaaaaa'),
(28, 157, 'xxxxxxxxxx'),
(29, 157, 'xxxxxxxxxx'),
(50, 158, 'aaaaaaaa2222222222222'),
(51, 158, 'sssssss11111111111'),
(54, 175, ''),
(55, 171, 'https://www.facebook.com/people/Lakshya-Softech/100063528715719/');

-- --------------------------------------------------------

--
-- Table structure for table `specialization`
--

CREATE TABLE `specialization` (
  `specialization_id` int NOT NULL,
  `speci_name` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `specialization`
--

INSERT INTO `specialization` (`specialization_id`, `speci_name`) VALUES
(1, 'Front-End Development'),
(2, 'Back-End Development'),
(3, 'Full-Stack Development'),
(4, 'Mobile App Development (iOS/Android)'),
(5, 'Web Design'),
(6, 'Web Accessibility'),
(7, 'Data Analysis'),
(8, 'Machine Learning'),
(9, 'Cybersecurity'),
(10, 'Cloud Architecture'),
(11, 'DevOps'),
(12, 'Database Administration'),
(13, 'Network Engineering'),
(14, 'UI Design'),
(15, 'UX Design'),
(16, 'Project Management'),
(17, 'Mobile Development (Android)'),
(18, 'Mobile Development (iOS)'),
(19, 'Game Design'),
(20, 'Quantum Computing');

-- --------------------------------------------------------

--
-- Table structure for table `str_month`
--

CREATE TABLE `str_month` (
  `str_month_id` int NOT NULL,
  `month` varchar(3) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `str_month`
--

INSERT INTO `str_month` (`str_month_id`, `month`) VALUES
(1, 'Jan'),
(2, 'Feb'),
(3, 'Mar'),
(4, 'Apr'),
(5, 'May'),
(6, 'Jun'),
(7, 'Jul'),
(8, 'Aug'),
(9, 'Sep'),
(10, 'Oct'),
(11, 'Nov'),
(12, 'Dec'),
(13, 'Jan'),
(14, 'Feb'),
(15, 'Mar'),
(16, 'Apr'),
(17, 'May'),
(18, 'Jun'),
(19, 'Jul'),
(20, 'Aug'),
(21, 'Sep'),
(22, 'Oct'),
(23, 'Nov'),
(24, 'Dec');

-- --------------------------------------------------------

--
-- Table structure for table `subscription`
--

CREATE TABLE `subscription` (
  `subscription_id` int NOT NULL,
  `user_id` int NOT NULL,
  `package_id` int NOT NULL,
  `start_date` varchar(50) NOT NULL,
  `expiration_date` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `subscription`
--

INSERT INTO `subscription` (`subscription_id`, `user_id`, `package_id`, `start_date`, `expiration_date`, `status`) VALUES
(29, 179, 10, '27-12-2023 02:14:40 pm', '24-12-2033 02:14:40 pm', 'Active'),
(30, 180, 13, '02-01-2024 01:04:16 pm', '01-02-2024 01:04:16 pm', 'active'),
(31, 182, 11, '28-12-2023 11:36:50 am', '27-01-2024 11:36:50 am', 'active'),
(32, 183, 10, '28-12-2023 02:06:37 pm', '25-12-2033 02:06:37 pm', 'Active'),
(33, 184, 10, '28-12-2023 02:18:51 pm', '25-12-2033 02:18:51 pm', 'Active'),
(34, 185, 10, '03-01-2024 01:58:14 pm', '31-12-2033 01:58:14 pm', 'Active'),
(35, 186, 10, '03-01-2024 02:12:41 pm', '31-12-2033 02:12:41 pm', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `technical_skills`
--

CREATE TABLE `technical_skills` (
  `technical_skills_id` int NOT NULL,
  `user_id` int NOT NULL,
  `skillName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `skillRating` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `technical_skills`
--

INSERT INTO `technical_skills` (`technical_skills_id`, `user_id`, `skillName`, `skillRating`) VALUES
(27, 157, 'sssaaaaaaaaaaaaaa', 2),
(28, 157, 'xxxxxxxxxx', 2),
(31, 158, 'ddddddddddddd', 1),
(32, 175, '', 8),
(33, 171, 'qqqqqqq', 1),
(34, 172, 'werwr2323423452', 2);

-- --------------------------------------------------------

--
-- Table structure for table `template`
--

CREATE TABLE `template` (
  ` temp_id` int NOT NULL,
  `Name` varchar(300) COLLATE utf8mb4_general_ci NOT NULL,
  `image` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `status` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `template`
--

INSERT INTO `template` (` temp_id`, `Name`, `image`, `type`, `status`) VALUES
(1, 'qqqqq', 'assest/templatePic/templatePic_1696429131207.jpg', 'qqqqqqqqq', 0),
(2, 'qqqqq', 'assest/templatePic/templatePic_1696429237554.jpg', 'qqqqqqqqq', 0),
(3, 'qqqqq', 'assest/templatePic/templatePic_1696429278553.jpg', 'qqqqqqqqq', 0),
(4, 'qqqqq', 'assest/templatePic/templatePic_1696429536777.jpg', 'qqqqqqqqq', 0),
(5, 'qqqqq', 'assest/templatePic/templatePic_1696429551466.jpg', 'qqqqqqqqq', 0),
(6, 'qqqqq', 'assest/templatePic/templatePic_1696493539125.jpg', 'qqqqqqqqq', 0),
(7, 'qqqqq', 'assest/templatePic/templatePic_1696493675584.jpg', 'qqqqqqqqq', 0),
(8, 'qqqqq', 'assest/templatePic/templatePic_1696493734851.jpg', 'qqqqqqqqq', 0),
(9, 'qqqqq', 'assest/templatePic/templatePic_1696493838797.jpg', 'qqqqqqqqq', 0),
(10, 'aaaaaa', 'assest/templatePic/templatePic_1696493866092.jpg', 'aaaaaaaa', 0),
(11, 'aaaaaa', 'assest/templatePic/templatePic_1696493891388.jpg', 'aaaaaaaa', 0),
(12, 'aaaaaa', 'assest/templatePic/templatePic_1696494039358.jpg', 'aaaaaaaa', 0);

-- --------------------------------------------------------

--
-- Table structure for table `template_master`
--

CREATE TABLE `template_master` (
  `template_id` int NOT NULL,
  `name` varchar(300) COLLATE utf8mb4_general_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `package_list_id` int NOT NULL,
  `template_number` int NOT NULL,
  `status` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `template_master`
--

INSERT INTO `template_master` (`template_id`, `name`, `image`, `type`, `package_list_id`, `template_number`, `status`) VALUES
(7, 'demo template', 'assest/templatePic/templatePic_1698741881207.jpg', '0', 0, 1, 'Active'),
(8, 'demo template2', 'assest/templatePic/templatePic_1698741910094.jpg', '1', 11, 2, 'Active'),
(10, 'abc', 'assest/templatePic/templatePic_1699951346900.jpg', '1', 12, 3, 'Active'),
(11, 'xyz', 'assest/templatePic/templatePic_1699951523410.jpg', '1', 13, 4, 'Active'),
(12, 'xyz', 'assest/templatePic/templatePic_1699951552480.jpg', '1', 15, 5, 'Active'),
(13, 'xyz', 'assest/templatePic/templatePic_1698741881208.png', '1', 15, 6, '1');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` int NOT NULL,
  `name` varchar(256) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `email` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `name`, `mobile`, `email`) VALUES
(1, 'Shailendra', '8422996373', 'shailendra@newtum.com');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int NOT NULL,
  `user_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `user_dob` date NOT NULL,
  `profile_pic` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(15) COLLATE utf8mb4_general_ci NOT NULL,
  `token` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `mode` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_dob`, `profile_pic`, `email`, `password`, `token`, `mode`) VALUES
(147, 'Shailendra Bramhvanshi', '0000-00-00', 'https://lh3.googleusercontent.com/a/ACg8ocIkKLK4USy3FbzGMYLqYdf6O9uz6-VkVnWh4_HEvAzECHI=s96-c', 'shailendra@newtumcom', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE0NywibmFtZSI6IlNoYWlsZW5kcmEgQnJhbWh2YW5zaGkiLCJwaWMiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NJa0tMSzRVU3kzRmJ6R01ZTHFZZGY2Tzl1ejYtVmtWbldoNF9IRXZBekVDSEk9czk2LWMiLCJpYXQiOjE3MDA5MTMxNTN9.u_g1Qb2b9EUsBw9k20O0r-mFtsfQEO2LmNCo6x_7dpA', 0),
(149, 'prakash', '0000-00-00', '', 'prakash@gmailcom', '123', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE0OSwibmFtZSI6InByYWthc2giLCJwaWMiOiIiLCJtb2RlIjoxLCJpYXQiOjE3MDEyNDExODd9.6JbNfyBFtW5z9jmshhpgwXOmXR0a3oFGfk6N9bTBQPk', 0),
(151, 'Lakshya Softech', '0000-00-00', 'https://lh3.googleusercontent.com/a/ACg8ocLQpYBfkBlJnLm0lpsvs1W8nC_KztmmAPRTzrR26CH-=s96-c', 'lakshyasoftechinfo@gmailcom', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE1MSwibmFtZSI6Ikxha3NoeWEgU29mdGVjaCIsInBpYyI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0xRcFlCZmtCbEpuTG0wbHBzdnMxVzhuQ19LenRtbUFQUlR6clIyNkNILT1zOTYtYyIsIm1vZGUiOjAsImlhdCI6MTcwMTI0MjM2M30.O6q_kNBUFh3zWRzmXtRjWaLVIWAFqgK-2WHtYcF4m4k', 0),
(170, 'Magic Point', '0000-00-00', 'https://lh3.googleusercontent.com/a/ACg8ocLB-a645g-jo-8R0XMGLd_8wu9oXlnLw92uRPvg0sP7=s96-c', 'magicpointhr@gmail.com', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE3MCwibmFtZSI6Ik1hZ2ljIFBvaW50IiwicGljIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EvQUNnOG9jTEItYTY0NWctam8tOFIwWE1HTGRfOHd1OW9YbG5MdzkydVJQdmcwc1A3PXM5Ni1jIiwiaWF0IjoxNzAyNzE1NjkwfQ.t_5bJXgsQvWDUI3CcJNPqJAPsf_73TDm66V3CZeUwCA', 0),
(171, 'Shailendra', '0000-00-00', '', 'Appu@123', 'Appu@123', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE3MSwibmFtZSI6IlNoYWlsZW5kcmEiLCJwaWMiOiIiLCJtb2RlIjoxLCJpYXQiOjE3MDE5NTI5MzV9.y-m8OyjzVYKlhIgsWhMVOUg4sFxgFxbGn9WiChnq_GA', 0),
(172, 'Shailendra', '0000-00-00', '', 'shailendra@newtum.com', 'Appu@123', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE3MiwibmFtZSI6IlNoYWlsZW5kcmEiLCJwaWMiOiIiLCJpYXQiOjE3MDE5NTI5ODF9.be21CTaXGfJlEafjORswxI66V_dfwZbRdS8_c_MKr9k', 0),
(173, 'dwerqrew', '0000-00-00', '', 'wertwertwer', 'twertwert', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE3MywibmFtZSI6ImR3ZXJxcmV3IiwicGljIjoiIiwibW9kZSI6MSwiaWF0IjoxNzAyMTkyNjk3fQ.rq35Qp-1GxSwdWE4U29dH4ok_SYtiL6B21-qsyeB4ak', 0),
(180, 'Vikash Rakesh', '0000-00-00', 'https://lh3.googleusercontent.com/a/ACg8ocK-lPIgElQq1y7EHmxxrqeVc4u3dJ7MN_OnwkyT2dIMnw=s96-c', 'vikashrakesh200@gmail.com', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE4MCwibmFtZSI6IlZpa2FzaCBSYWtlc2giLCJlbWFpbCI6InZpa2FzaHJha2VzaDIwMEBnbWFpbC5jb20iLCJwaWMiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NLLWxQSWdFbFFxMXk3RUhteHhycWVWYzR1M2RKN01OX09ud2t5VDJkSU1udz1zOTYtYyIsIm1vZGUiOjAsImlhdCI6MTcwMzY2NzI5Mn0.rYMYk1SxI02dEna_inkZhiXWsyYKdWzbylaNFebi2AI', 0),
(184, 'VISHWANTH KUMAR PATER', '0000-00-00', 'https://lh3.googleusercontent.com/a/ACg8ocLBDWNvmnWv2XtKMIxI7Fo7BhqzGewxiqFMklUxq2hsZA=s96-c', 'visupater@gmail.com', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE4NCwibmFtZSI6IlZJU0hXQU5USCBLVU1BUiBQQVRFUiIsInBpYyI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0xCRFdOdm1uV3YyWHRLTUl4STdGbzdCaHF6R2V3eGlxRk1rbFV4cTJoc1pBPXM5Ni1jIiwiaWF0IjoxNzA0Nzg0ODg0fQ.9K2ofKjOytUwMj4Jn1Txey8tjmCq3guqgbK3_18BxYU', 0),
(185, 'Shailendra Bramhvanshi', '0000-00-00', 'https://lh3.googleusercontent.com/a/ACg8ocKPsPrDMYMrl7oQmb3B2o-hntW71vXM22bBHGVtPLqj=s96-c', 'techlink.project@gmail.com', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE4NSwibmFtZSI6IlNoYWlsZW5kcmEgQnJhbWh2YW5zaGkiLCJlbWFpbCI6InRlY2hsaW5rLnByb2plY3RAZ21haWwuY29tIiwicGljIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EvQUNnOG9jS1BzUHJETVlNcmw3b1FtYjNCMm8taG50VzcxdlhNMjJiQkhHVnRQTHFqPXM5Ni1jIiwibW9kZSI6MCwiaWF0IjoxNzA0MjcwNDk0fQ.AUACn6Rh2A1FYqsnEPmT9kwHLily6XbtEzV2TZI3huk', 0),
(186, 'Newtum Info', '0000-00-00', 'https://lh3.googleusercontent.com/a/ACg8ocKes7po2HgvwvN22IpbutQLKF4AombVwWT3kOnPmo2_rM8=s96-c', 'info@newtum.com', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE4NiwibmFtZSI6Ik5ld3R1bSBJbmZvIiwiZW1haWwiOiJpbmZvQG5ld3R1bS5jb20iLCJwaWMiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NLZXM3cG8ySGd2d3ZOMjJJcGJ1dFFMS0Y0QW9tYlZ3V1Qza09uUG1vMl9yTTg9czk2LWMiLCJtb2RlIjowLCJpYXQiOjE3MDQyNzEzNjF9.jDjLaU1DwH9TlsZpkPUHU27H7Ws5L6FGf1GfNLGtpjE', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_cover_page`
--

CREATE TABLE `user_cover_page` (
  `cover_page_id` int NOT NULL,
  `user_id` int NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `cover_page` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_cover_page`
--

INSERT INTO `user_cover_page` (`cover_page_id`, `user_id`, `company_name`, `cover_page`) VALUES
(22, 158, '', '<p>Hi,</p><p>This is regardingto job.</p><p><br></p><p>I have worked as frontend drv..</p><p><br></p><p>Thanks,</p><p>Vishwanath</p><p>Mob: 7858256325</p>'),
(23, 169, 'Infos Int', '<p>Hi HR,</p><p><br></p><p>My Name is Vishwanath.</p><p><br></p><p>I am working as project manager.</p><p><br></p><p>Thanks,</p><p>Vishwanath kumar pater</p><p>Hi HR,</p><p><br></p><p>My Name is Vishwanath.</p><p><br></p><p>I am working as project manager.</p><p><br></p><p>Thanks,</p><p>Vishwanath kumar pater</p><p>Hi HR,</p><p><br></p><p>My Name is Vishwanath.</p><p><br></p><p>I am working as project manager.</p><p><br></p><p>Thanks,</p><p>Vishwanath kumar pater</p><p>Hi HR,</p><p><br></p><p>My Name is Vishwanath.</p><p><br></p><p>I am working as project manager.</p><p><br></p><p>Thanks,</p><p>Vishwanath kumar pater</p><p>Hi HR,</p><p><br></p><p>My Name is Vishwanath.</p><p><br></p><p>I am working as project manager.</p><p><br></p><p>Thanks,</p><p>Vishwanath kumar pater</p><p>Hi HR,</p><p><br></p><p>My Name is Vishwanath.</p><p><br></p><p>I am working as project manager.</p><p><br></p><p>Thanks,</p><p>Vishwanath kumar pater</p>'),
(24, 169, 'VnD Infotech', '<p>Hi HR,</p><p><br></p><p>My Name is Rahul.</p><p><br></p><p>I am working as project manager.</p><p><br></p><p>Thanks,</p><p>Rahul Sinha</p>'),
(25, 169, 'Wipro', '<p>Hi</p><p><br></p><p>I am working as team lead</p><p><br></p><p>Thanks</p><p>Vishu</p>'),
(26, 169, 'Lnt infotech', '<p>Hi</p><p>I am working as software engineer</p><p><br></p><p>Thaks,</p><p>Vishwanath</p>'),
(27, 182, 'Lnt TS Bangalore', '<p>Hi</p><p><br></p><p>I am working as software engineer.</p><p><br></p><p>Thanks,</p><p>Vishwanath kumar pater</p>'),
(28, 182, 'Wipro Banfalore', '<p>Hi HR,</p><p><br></p><p>My name is Rahul.</p><p><br></p><p>Thanks,</p><p>Rahul Sinha</p><p>785852458</p>'),
(29, 180, 'Lakshya softech', '<p>I am a highly motivated individual with a passion for continuous learning and growth. My strong communication and problem-solving skills have enabled me to excel in various roles. With a keen eye for detail and a drive for excellence, I am confident in my ability to contribute positively to any team.</p>'),
(30, 180, 'Formac', '<p>I am a highly motivated individual with a passion for continuous learning and growth. With a strong background in various industries, I possess a diverse skill set and am able to adapt to new environments quickly. My dedication and determination have allowed me to excel in my career and I am eager to take on new challenges.</p>'),
(31, 180, 'hghgg', '<p>I have over 1,000 hours of experience in various industries, including customer service and project management. My strong communication skills and attention to detail have allowed me to excel in these roles. I am confident in my ability to adapt to new environments and contribute to the success of any team.</p>'),
(32, 184, 'Demo Company LTD', '<p>hi</p><p>jjjhhhhhhhhhhhhh</p><p>jjjjjjjjjjjjjj</p><p><br></p><p>tttttt</p>'),
(33, 184, 'sssssss', '<p>Hi</p><p><br></p><p>Thankskkkkkkkkkkkkkkkkkkkkkkkk</p><p>sssssssssssssssssssssss</p><p>Thanks,</p><p>Vishwanath</p>'),
(34, 184, 'Test Company', '<p>Hi,</p><p><br></p><p>I am a highly motivated individual with a strong work ethic and a passion for learning. I have excellent communication skills and am able to work well in a team environment. I am also highly organized and detail-oriented, ensuring that all tasks are completed efficiently and accurately.</p><p><br></p><p><br></p><p>Thanks</p>'),
(35, 185, 'Techaroha Solutions Private Limited', '<p>Test</p>'),
(36, 186, 'test', '<p>Test test test</p>'),
(37, 186, 'Test2', '<p>Test2</p>'),
(38, 184, '', '<p>sssssssssssssssssssssssssssssssssssss</p>'),
(39, 184, 'fff3333', '<p>ffffffffffff3333333333</p>');

-- --------------------------------------------------------

--
-- Table structure for table `work_experience`
--

CREATE TABLE `work_experience` (
  `work_experience_id` int NOT NULL,
  `user_id` int NOT NULL,
  `company` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `jobTitle` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `currentCompany` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `workSinceYear` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `worksincemonth` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `workSincetoYear` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `worksincetomonth` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `workedTill` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `descp` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `work_experience`
--

INSERT INTO `work_experience` (`work_experience_id`, `user_id`, `company`, `jobTitle`, `currentCompany`, `workSinceYear`, `worksincemonth`, `workSincetoYear`, `worksincetomonth`, `workedTill`, `descp`) VALUES
(166, 157, 'Lnt', 'Software Engineer at Lnt', 'No', '2006', 'Feb', '2010', 'May', 'Present', 'working as software engineer'),
(167, 157, 'CSS Crp', 'Team lead ', 'Yes', '2011', 'Apr', '', '', 'Present', 'working as team lead. here'),
(171, 158, 'Test Corp LTD Bangalore', 'Software eng', 'No', '2006', 'Feb', '2011', 'Mar', 'Present', 'ave extensive experience in various industries, including marketing, finance, and technology. My skills include project management, data analysis, and communication. I am a quick learner and thrive in fast-paced environments. I am seeking a challenging role where I can utilize my skills and contribute to the growth of the company.'),
(172, 158, 'Demo LTD Bangalore', 'ddddddddd', 'Yes', '2012', 'Apr', '', '', 'Present', 'ddddddddddddddddddddddd'),
(173, 163, 'dddddd', 'dddddd', 'No', '2007', 'Jan', '2007', 'Feb', 'Present', 'ddddddddddddd'),
(174, 149, 'pppppp', 'ppppppppp', ' ', '', '', '', '', 'Present', ''),
(178, 170, '', '', ' ', '', '', '', '', 'Present', ''),
(179, 170, '', '', '', '', '', '', '', 'Present', ''),
(180, 169, 'ss', 'ss', 'Yes', '', '', '', '', 'Present', 'sss'),
(184, 172, '', 'Co founder123123123', 'Yes', '2015', 'Jan', '', '', 'Present', 'Heelo how are yuou'),
(185, 172, 'Techaorha ', 'Founder', 'Yes', '2014', 'Aug', '', '', 'Present', 'Nothing I am just a founder'),
(186, 174, '', '', 'No', '2021', 'Sep', '2021', 'Oct', 'Present', ''),
(187, 184, 'ssss', 'sssssssss', 'Yes', '2021', 'Apr', '', '', 'Present', 'sssssssssssssssssssssssssssssssss'),
(195, 171, 'ttttttt', 'tttttttt', ' ', '2009', 'Feb', '2014', 'Mar', 'Present', 'ttttttttt'),
(196, 171, 'ssssss', 'sssssssss', 'Yes', '2021', 'May', '', '', 'Present', 'ssssssss');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `admin_super`
--
ALTER TABLE `admin_super`
  ADD PRIMARY KEY (`super_admin_id`);

--
-- Indexes for table `certification`
--
ALTER TABLE `certification`
  ADD PRIMARY KEY (`certificate_id`);

--
-- Indexes for table `contact_us_db`
--
ALTER TABLE `contact_us_db`
  ADD PRIMARY KEY (`contact_us_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `cover_letter`
--
ALTER TABLE `cover_letter`
  ADD PRIMARY KEY (`cover_letter_id`);

--
-- Indexes for table `credit_point`
--
ALTER TABLE `credit_point`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `custom_section`
--
ALTER TABLE `custom_section`
  ADD PRIMARY KEY (`custom_section_id`);

--
-- Indexes for table `default_credit_point`
--
ALTER TABLE `default_credit_point`
  ADD PRIMARY KEY (`credit_point_id`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`education_id`);

--
-- Indexes for table `email_verification`
--
ALTER TABLE `email_verification`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `extra_curricular_activities`
--
ALTER TABLE `extra_curricular_activities`
  ADD PRIMARY KEY (`extra_curricular_activities_id`);

--
-- Indexes for table `grading_system`
--
ALTER TABLE `grading_system`
  ADD PRIMARY KEY (`grading_system_id`);

--
-- Indexes for table `hobbies`
--
ALTER TABLE `hobbies`
  ADD PRIMARY KEY (`hobbies_id`);

--
-- Indexes for table `int_str_month`
--
ALTER TABLE `int_str_month`
  ADD PRIMARY KEY (`int_str_month_id`);

--
-- Indexes for table `int_str_year`
--
ALTER TABLE `int_str_year`
  ADD PRIMARY KEY (`int_str_year_id`);

--
-- Indexes for table `int_year_master`
--
ALTER TABLE `int_year_master`
  ADD PRIMARY KEY (`int_year_id`);

--
-- Indexes for table `language`
--
ALTER TABLE `language`
  ADD PRIMARY KEY (`language_id`);

--
-- Indexes for table `other_personal_details`
--
ALTER TABLE `other_personal_details`
  ADD PRIMARY KEY (`other_personal_details_id`);

--
-- Indexes for table `package_list`
--
ALTER TABLE `package_list`
  ADD PRIMARY KEY (`package_list_id`),
  ADD UNIQUE KEY `package_list_id` (`package_list_id`);

--
-- Indexes for table `payment_summary`
--
ALTER TABLE `payment_summary`
  ADD PRIMARY KEY (`payment_summary_id`);

--
-- Indexes for table `personal_details`
--
ALTER TABLE `personal_details`
  ADD PRIMARY KEY (`other_personal_details_id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `skill`
--
ALTER TABLE `skill`
  ADD PRIMARY KEY (`skill_id`);

--
-- Indexes for table `social_link`
--
ALTER TABLE `social_link`
  ADD PRIMARY KEY (`social_link_id`);

--
-- Indexes for table `specialization`
--
ALTER TABLE `specialization`
  ADD PRIMARY KEY (`specialization_id`);

--
-- Indexes for table `str_month`
--
ALTER TABLE `str_month`
  ADD PRIMARY KEY (`str_month_id`);

--
-- Indexes for table `subscription`
--
ALTER TABLE `subscription`
  ADD PRIMARY KEY (`subscription_id`);

--
-- Indexes for table `technical_skills`
--
ALTER TABLE `technical_skills`
  ADD PRIMARY KEY (`technical_skills_id`);

--
-- Indexes for table `template`
--
ALTER TABLE `template`
  ADD PRIMARY KEY (` temp_id`);

--
-- Indexes for table `template_master`
--
ALTER TABLE `template_master`
  ADD PRIMARY KEY (`template_id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_cover_page`
--
ALTER TABLE `user_cover_page`
  ADD PRIMARY KEY (`cover_page_id`);

--
-- Indexes for table `work_experience`
--
ALTER TABLE `work_experience`
  ADD PRIMARY KEY (`work_experience_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admin_super`
--
ALTER TABLE `admin_super`
  MODIFY `super_admin_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `certification`
--
ALTER TABLE `certification`
  MODIFY `certificate_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT for table `contact_us_db`
--
ALTER TABLE `contact_us_db`
  MODIFY `contact_us_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `cover_letter`
--
ALTER TABLE `cover_letter`
  MODIFY `cover_letter_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `credit_point`
--
ALTER TABLE `credit_point`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `custom_section`
--
ALTER TABLE `custom_section`
  MODIFY `custom_section_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `default_credit_point`
--
ALTER TABLE `default_credit_point`
  MODIFY `credit_point_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `education`
--
ALTER TABLE `education`
  MODIFY `education_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT for table `email_verification`
--
ALTER TABLE `email_verification`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `extra_curricular_activities`
--
ALTER TABLE `extra_curricular_activities`
  MODIFY `extra_curricular_activities_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `grading_system`
--
ALTER TABLE `grading_system`
  MODIFY `grading_system_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hobbies`
--
ALTER TABLE `hobbies`
  MODIFY `hobbies_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `int_str_month`
--
ALTER TABLE `int_str_month`
  MODIFY `int_str_month_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `int_str_year`
--
ALTER TABLE `int_str_year`
  MODIFY `int_str_year_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `int_year_master`
--
ALTER TABLE `int_year_master`
  MODIFY `int_year_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `language`
--
ALTER TABLE `language`
  MODIFY `language_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `other_personal_details`
--
ALTER TABLE `other_personal_details`
  MODIFY `other_personal_details_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `package_list`
--
ALTER TABLE `package_list`
  MODIFY `package_list_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `payment_summary`
--
ALTER TABLE `payment_summary`
  MODIFY `payment_summary_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `personal_details`
--
ALTER TABLE `personal_details`
  MODIFY `other_personal_details_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `project_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `skill`
--
ALTER TABLE `skill`
  MODIFY `skill_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `social_link`
--
ALTER TABLE `social_link`
  MODIFY `social_link_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `specialization`
--
ALTER TABLE `specialization`
  MODIFY `specialization_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `str_month`
--
ALTER TABLE `str_month`
  MODIFY `str_month_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `subscription`
--
ALTER TABLE `subscription`
  MODIFY `subscription_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `technical_skills`
--
ALTER TABLE `technical_skills`
  MODIFY `technical_skills_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `template`
--
ALTER TABLE `template`
  MODIFY ` temp_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `template_master`
--
ALTER TABLE `template_master`
  MODIFY `template_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;

--
-- AUTO_INCREMENT for table `user_cover_page`
--
ALTER TABLE `user_cover_page`
  MODIFY `cover_page_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `work_experience`
--
ALTER TABLE `work_experience`
  MODIFY `work_experience_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=197;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
