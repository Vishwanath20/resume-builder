import React, { useState, useEffect } from 'react';
import { Link, useParams } from "react-router-dom"
import { apiUrl } from "../core/ApiConfig";
import axios from "axios";

export default function UpdatePackageMaster() {

    // Get the userId param from the URL.
    let { packageId } = useParams();



    // States
    const [packageName, setpackageName] = useState('');
    const [price, setPrice] = useState('');
    //const [templateData, setTemplateData] = useState([]);
    const [totalAmount, setTotalAmount] = useState('');

    const [templateData, setTemplateData] = useState({ package_name: '', price: '', credential_amount: '' });

    // States for checking the errors
    const [submitted, setSubmitted] = useState(false);
    const [error, setError] = useState(false);

    useEffect(() => {

        reflectTemplateMasterData(packageId)
    }, [])

    //Reflect-Template-MasterData Template Master Data API Call
    const reflectTemplateMasterData = async (packageId) => {

        try {

            const response = await axios.get(apiUrl() + `/get-package-master/${packageId}`);
            if (response.data.statusCode == "200") {

                const tempData = {
                    package_name: response.data.templateMasterData[0].package_name,
                    price: response.data.templateMasterData[0].price,
                    credential_amount: response.data.templateMasterData[0].credential_amount

                }

                setTemplateData(tempData);

            }
            else {
                console.log(response.data.status)
            }

        } catch (error) {
            console.error(error);
        }
    }

    // Handling the package name change
    const handlePackageName = (e) => {

        //  templateData.package_name;
        setpackageName(e.target.value);
        setSubmitted(false);
    };

    // Handling the price change
    const handlePrice = (e) => {
        setPrice(e.target.value);
        setSubmitted(false);
    };




    // Handling the Total Amount change
    const handlTotalAmount = (e) => {
        setTotalAmount(e.target.value);
        setSubmitted(false);
    };

    // Handling the form submission
    const handleSubmit = (e) => {

        e.preventDefault();
        if (packageName === '' || price === '' || totalAmount === '') {
            setError(true);
        } else {
            setSubmitted(true);
            setError(false);
            const formData = {
                package_name: packageName,
                price: price,
                credential_amount: totalAmount
            }


            updatetTemplateMasterData(formData);
        }
    };

    const updatetTemplateMasterData = async (formData) => {
        //  setTemplateData(templateData, formData);

        try {

            const response = await axios.put(apiUrl() + `/update-package-master`, {
                templateData: formData,
                packageId: packageId
            });


            if (response.data.statusCode == "200") {
                console.log(response.data.status)
            }
            else {
                console.log(response.data.status)
            }

        } catch (error) {
            console.error(error);
        }
    }


    // Showing success message
    const successMessage = () => {
        // return (
        //   <div
        //     className="success"
        //     style={{
        //       display: submitted ? '' : 'none',
        //     }}>
        //     <h1>User {name} successfully registered!!</h1>
        //   </div>
        // );
        if (submitted) {
            alert("Package Added Successfully!!!");
            // window.location.reload();
        }
    };

    // Showing error message if error is true
    const errorMessage = () => {
        return (
            <div
                className="error"
                style={{
                    display: error ? '' : 'none',
                }}>
                <h5 className='text-danger text-center'>Please enter all the fields *</h5>
            </div>
        );
    };
    return (
        <>

            <div className="container-fluid mt-3">
                <div className="card card-body w-50 m-auto mt-5">

                    <h2 className="text-center m-4">Update Package Master</h2>
                    {/* Calling to the methods */}
                    <div className="messages m-2">
                        {errorMessage()}
                        {successMessage()}
                    </div>

                    <form className="text-center">
                        <div className="mb-3 mt-3">
                            <div className="row m-2">
                                <div className="col-sm-12">
                                    <label htmlFor="year" className="m-2">Package Name</label>
                                    <input type="text" className="form-control " id="pkg_name"
                                        placeholder="Enter Package" name="pkg_name" defaultValue={templateData.package_name || ''} onChange={handlePackageName}></input>
                                </div>

                            </div>
                            <div className="row m-2">
                                <div className="col-sm-6">
                                    <label htmlFor="year" className="m-2">Price</label>
                                    <input type="text" className="form-control " id="pkg_name" placeholder="Enter Amount"
                                        name="pkg_name" defaultValue={templateData.price || ''} onChange={handlePrice}></input>
                                </div>
                                <div className="col-sm-6">
                                    <label htmlFor="year" className="m-2">Total Amount</label>
                                    <input type="text" className="form-control " id="pkg_name" placeholder="Enter Amount"
                                        name="pkg_name" defaultValue={templateData.credential_amount || ''} onChange={handlTotalAmount}></input>
                                </div>
                            </div>

                            <button type="submit" className="btn btn-primary mt-4" onClick={handleSubmit}>Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </>
    )
}