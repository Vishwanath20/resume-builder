import React, { useState, useEffect } from 'react';
import axios from "axios";
import { apiUrl } from "../core/ApiConfig";
import { useNavigate } from 'react-router-dom';
import { Link, useParams } from "react-router-dom"

export default function UserDetail() {

   const [userData, setUserData] = useState([]);

   let { uid } = useParams();

   useEffect(() => {

      getUserDetail(uid);
   }, []);

   const getUserDetail = async (uid) => {
      try {
         const response = await axios.get(apiUrl() + `/get-users-detail/${uid}`);

         if (response.data.statusCode == "200") {
            var userDataTable = response.data.userData.map((dataObj) => {

               return (
                  <tbody>
                     <tr>
                        <td className="  ">Full Name</td>
                        <td>{dataObj.user_name}</td>

                     </tr>

                     <tr>
                        <td className="  ">Email</td>
                        <td>{dataObj.email}</td>

                     </tr>

                     <tr>
                        <td className="  ">Phone</td>
                        <td>{dataObj.user_dob}</td>
                     </tr>

                  </tbody>
               )
            })

            setUserData(userDataTable);
         }
         else {
            console.log(response.data.status)
         }

      } catch (error) {
         console.error(error);
      }
   }


   return (

      <div className="container-fluid mt-3">

         <div className="card card-body">
            <div className="row">
               <h3 className="col-sm-12 text-center m-2">USER DETAILS</h3>
            </div>
            <table className="table-responsive-sm table table-hover table-bordered">

               {userData}
            </table>
         </div>
      </div>
   )
}