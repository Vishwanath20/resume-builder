import { useEffect, useState } from 'react';
import axios from "axios";
import { apiUrl } from "../core/ApiConfig";
import { Link } from "react-router-dom"

export default function PackageMaster() {

  // States for checking the errors
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(false);

  // States
  const [packageData, setPackageData] = useState([]);
  const [packageName, setpackageName] = useState('');
  const [price, setPrice] = useState('');
  const [numOfTemplate, setNumOfTemplate] = useState('');
  const [coverLetter, setCoverLetter] = useState('');
  const [creditPointsAI, setcreditPointsAI] = useState('');
  const [premium10x, setPremium10x] = useState('');
  const [waterMark, setWaterMark] = useState('');
  const [premiumTemplate, setPremiumTemplate] = useState('');
  const [downloadOption, setDownloadOption] = useState('');
  const [emailSupport, setEmailSupport] = useState('');
  const [phoneSupport, setPhoneSupport] = useState('');
  const [portfolio, setPortfolio] = useState('');
  const [customDomain, setCustomDomain] = useState('');
  const [deductCreditPoint, setDeductCreditPoint] = useState('');

  useEffect(() => {
    getPackageMasterData()
  }, [])

  const handleDeductCreditPoint = (e) => {
    setDeductCreditPoint(e.target.value);
    setSubmitted(false);
  }

  // Handling the package name change
  const handlePackageName = (e) => {
    setpackageName(e.target.value);
    setSubmitted(false);
  };

  // Handling the price change
  const handlePrice = (e) => {
    setPrice(e.target.value);
    setSubmitted(false);
  };

  // Handling the  Num Of Template
  const handleNumOfTemplate = (e) => {
    setNumOfTemplate(e.target.value);
    setSubmitted(false);
  };

  const handleCoverLetter = (e) => {
    setCoverLetter(e.target.value);
    setSubmitted(false);
  };

  const handleCreditPointsAI = (e) => {
    setcreditPointsAI(e.target.value);
    setSubmitted(false);
  };

  const handlePremium10x = (e) => {
    setPremium10x(e.target.value);
    setSubmitted(false);
  };

  const handleMagicPointWaterMark = (e) => {
    setWaterMark(e.target.value);
    setSubmitted(false);
  };

  const handlePremiumTemplates = (e) => {
    setPremiumTemplate(e.target.value);
    setSubmitted(false);
  };

  const handleDownloadOption = (e) => {
    setDownloadOption(e.target.value);
    setSubmitted(false);
  };

  const handleEmailSupport = (e) => {
    setEmailSupport(e.target.value);
    setSubmitted(false);
  };

  const handlePhoneSupport = (e) => {
    setPhoneSupport(e.target.value);
    setSubmitted(false);
  };

  const handlePortfolio = (e) => {
    setPortfolio(e.target.value);
    setSubmitted(false);
  };

  const handleCustomDomainPortfolio = (e) => {
    setCustomDomain(e.target.value);
    setSubmitted(false);
  };

  // Handling the form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (packageName === '' || price === '' || numOfTemplate === '' || coverLetter === ''
      || creditPointsAI === '' || premium10x === '' || waterMark === '' || deductCreditPoint === ''
      || premiumTemplate === '' || downloadOption === ''
      || emailSupport === '' || phoneSupport === '' || portfolio === '' || customDomain === '') {
      setError(true);
    } else {
      setSubmitted(true);
      setError(false);
      const formData = {
        packageName: packageName,
        price: price,
        numOfTemplate: numOfTemplate,
        coverLetter: coverLetter,
        creditPointsAI: creditPointsAI,
        premium10x: premium10x,
        waterMark: waterMark,
        premiumTemplate: premiumTemplate,
        downloadOption: downloadOption,
        emailSupport: emailSupport,
        phoneSupport: phoneSupport,
        portfolio: portfolio,
        customDomain: customDomain,
        deductCreditPoint: deductCreditPoint
      }

      postTemplateMasterData(formData);
    }
  };

  //post Data API Call
  const postTemplateMasterData = async (formData) => {

    try {
      const response = await axios.post(apiUrl() + '/post-package-master', formData);

      if (response.data.statusCode == "200") {

        console.log(response.data.status)
      }
      else {
        console.log(response.data.status)
      }

    } catch (error) {
      console.error(error);
    }
  }

  //GET Package  Data API Call
  const getPackageMasterData = async () => {

    try {
      const response = await axios.get(apiUrl() + '/get-package-master');

      if (response.data.statusCode == "200") {

        setPackageData(...packageData, response.data.packageListData);

        console.log(response.data.status)
      }
      else {
        console.log(response.data.status)
      }

    } catch (error) {
      console.error(error);
    }
  }

  //DELETE Template Master Data API Call
  const deletePackageMasterData = async (packageId) => {

    try {
      const response = await axios.get(apiUrl() + `/delete-package-master/${packageId}`);
      if (response.data.statusCode == "200") {

        window.location.reload();
      }
      else {
        console.log(response.data.status)
      }
    } catch (error) {
      console.error(error);
    }
  }

  // Showing success message
  const successMessage = () => {
    // return (
    //   <div
    //     className="success"
    //     style={{
    //       display: submitted ? '' : 'none',
    //     }}>
    //     <h1>User {name} successfully registered!!</h1>
    //   </div>
    // );
    if (submitted) {
      alert("Package Added Successfully!!!");
      //  window.location.reload();
    }
  };

  // Showing error message if error is true
  const errorMessage = () => {
    return (
      <div
        className="error"
        style={{
          display: error ? '' : 'none',
        }}>
        <h1>Please enter all the fields</h1>
      </div>
    );
  };

  return (
    <>

      <div className="card card-body w-75 m-auto mt-5">

        <h2 className="text-center m-4">Package Master</h2>
        {/* Calling to the methods */}
        <div className="messages">
          {errorMessage()}
          {successMessage()}
        </div>

        <form className="text-center ">
          <div className="mb-3 mt-3">
            <div className="row m-2">
              <div className="col-sm-6 ">
                <label htmlFor="year" className="m-2">Package Name</label>
                <input type="text" className="form-control " id=""
                  placeholder="Enter Package" name="package_name" onChange={handlePackageName}></input>
              </div>
              <div className="col-sm-6">
                <label htmlFor="year" className="m-2">Price</label>
                <input type="text" className="form-control" id="" placeholder="Enter Price"
                  name="price" onChange={handlePrice}></input>
              </div>

            </div>


            <div className="row m-2">
              <div className="col-sm-6">
                <label htmlFor="year" className="m-2">Cover Letter</label>
                <input type="text" className="form-control" id="" placeholder="Enter Cover Letter Number"
                  name="coverLetter" onChange={handleCoverLetter}></input>
              </div>
              <div className="col-sm-6">
                <label htmlFor="year" className="m-2">No. Of Template</label>
                <input type="text" className="form-control" id="" placeholder="Enter No. of Template"
                  name="NoOfTemplate" onChange={handleNumOfTemplate}></input>
              </div>
            </div>


            <div className="row m-2">
              <div className="col-sm-6">
                <label htmlFor="year" className="m-2">Normal AI Per Year(Credit Point)</label>
                <input type="text" className="form-control" id="" placeholder="Enter Normal AI"
                  name="creditPointsAI" onChange={handleCreditPointsAI}></input>
              </div>
              <div className="col-sm-6">
                <label htmlFor="" className="m-2">Deduct Credit Point</label>
                <input type="text" className="form-control" id="" placeholder="Enter Deduct Credit Point per click"
                  name="DeductCreditPoint" onChange={handleDeductCreditPoint}></input>
              </div>
            </div>

            <div className="row m-2">
              <div className="col-sm-6">
                <label htmlFor="year" className="m-2">Premium 10X Powerful AI Engine</label>
                <select className="form-control" onChange={handlePremium10x}>
                  <option>Select Option</option>
                  <option>Yes</option>
                  <option>No</option>
                </select>
              </div>
              <div className="col-sm-6">
                <label htmlFor="year" className="m-2">MagicPoint Water Mark</label>
                <select className="form-control" onChange={handleMagicPointWaterMark}>
                  <option>Select Option</option>
                  <option>Yes</option>
                  <option>No</option>
                </select>
              </div>
            </div>

            <div className="row m-2">
              <div className="col-sm-6">
                <label htmlFor="year" className="m-2">Premium Templates</label>
                <select className="form-control" onChange={handlePremiumTemplates}>
                  <option>Select Option</option>
                  <option>Yes</option>
                  <option>No</option>
                </select>
              </div>
              <div className="col-sm-6">
                <label htmlFor="year" className="m-2">Download Option</label>
                <select className="form-control" onChange={handleDownloadOption}>
                  <option>Select Option</option>
                  <option>Yes</option>
                  <option>No</option>
                </select>
              </div>
            </div>

            <div className="row m-2">
              <div className="col-sm-6">
                <label htmlFor="year" className="m-2">Email Support</label>
                <select className="form-control" onChange={handleEmailSupport}>
                  <option>Select Option</option>
                  <option>Yes</option>
                  <option>No</option>
                </select>
              </div>
              <div className="col-sm-6">
                <label htmlFor="year" className="m-2">Phone Support</label>
                <select className="form-control" onChange={handlePhoneSupport}>
                  <option>Select Option</option>
                  <option>Yes</option>
                  <option>No</option>
                </select>

              </div>
            </div>

            <div className="row m-2">
              <div className="col-sm-6">
                <label htmlFor="year" className="m-2">Portfolio</label>
                <select className="form-control" onChange={handlePortfolio}>
                  <option>Select Option</option>
                  <option>Yes</option>
                  <option>No</option>
                </select>
              </div>
              <div className="col-sm-6">
                <label htmlFor="year" className="m-2">Custom Domain Portfolio</label>
                <select className="form-control"
                  onChange={handleCustomDomainPortfolio}>
                  <option>Select Option</option>
                  <option>Yes</option>
                  <option>No</option>
                </select>
              </div>
            </div>
            <button type="submit" className="btn btn-success mt-4" onClick={handleSubmit}>Submit</button>
          </div>
        </form>

      </div>

      <div className='mt-5 mb-5'>
        <div className="card card-body m-auto mt-5">
          <h3 className="text-center m-4">Available Packages</h3>
          <div style={{ maxWidth: '150vh' }} className="table-responsive">
            <table className="table table-hover table-bordered text-center">
              <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>Package Name</th>
                  <th>Price</th>
                  <th>Number Of Template</th>
                  <th>Cover Letter</th>
                  <th>Normal AI</th>
                  <th>premium 10x</th>
                  <th>Water Mark</th>
                  <th>Premium Template</th>
                  <th>Download Option</th>
                  <th>Email Support</th>
                  <th>Phone Support</th>
                  <th>Portfolio</th>
                  <th>Custom Domain</th>
                </tr>
              </thead>
              <tbody>

                {packageData ? (
                  packageData.map((dataObj, index) => (

                    <tr key={dataObj.package_list_id}>
                      <td>{index + 1}</td>
                      <td>{dataObj.package_name}</td>
                      <td>{dataObj.price}</td>
                      <td>{dataObj.num_of_template}</td>
                      <td>{dataObj.cover_letter}</td>
                      <td>{dataObj.normal_ai}</td>
                      <td>{dataObj.premium_powerful_AI}</td>
                      <td>{dataObj.water_mark}</td>
                      <td>{dataObj.premium_template}</td>
                      <td>{dataObj.download_option}</td>
                      <td>{dataObj.email_support}</td>
                      <td>{dataObj.phone_support}</td>
                      <td>{dataObj.portfolio}</td>
                      <td>{dataObj.custom_domain}</td>

                      <td>
                        <Link to={`/UpdatePackageMaster/${dataObj.package_list_id}`} > <button className="btn btn-primary mr-3">Update</button></Link>
                      </td>
                      <td>
                        <button className="btn btn-danger" onClick={() => deletePackageMasterData(`${dataObj.package_list_id}`)}>Delete</button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <p></p>
                )}
              </tbody>
            </table>
          </div>
        </div>


      </div>
    </>
  )
}