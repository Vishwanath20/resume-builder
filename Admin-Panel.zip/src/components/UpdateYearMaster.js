import React, { useState, useEffect } from 'react';
import { Link, useParams } from "react-router-dom"
import { apiUrl } from "../core/ApiConfig";
import axios from "axios";

export default function UpdateYearMaster() {

    const [yearData, setYearData] = useState([]);
    const [year, setYear] = useState('');

    // Get the userId param from the URL.
    let { yearid } = useParams();

    useEffect(() => {

        getYearMasterData(yearid);
    }, []);



    let yData;
    const getYearMasterData = async (yearid) => {

        try {
            const response = await axios.get(apiUrl() + `/get-year-master/${yearid}`);

            if (response.data.statusCode == "200") {
                yData = response.data.yearData[0].year;

                setYearData(response.data.yearData[0].year);

            }
            else {
                console.log(response.data.status)
            }

        } catch (error) {
            console.error(error);
        }
    }

    // Handling the name change
    const handleUpdateYear = (e) => {
        setYearData(e.target.value);
        //setSubmitted(false);
    };

    // Handling the form submission
    const handleSubmit = (e) => {

        e.preventDefault();
        if (yearData === '') {
            // setError(true);
        } else {
            // setSubmitted(true);
            //   setError(false);

            updateYearMasterData(yearData);
        }
    };

    const updateYearMasterData = async (yearData) => {

        try {

            const response = await axios.put(apiUrl() + `/update-year-master`, {
                year: yearData,
                yearid: yearid
            });

            if (response.data.statusCode == "200") {
                console.log(response.data.status)
            }
            else {
                console.log(response.data.status)
            }

        } catch (error) {
            console.error(error);
        }
    }

    return (
        <>
            <div className="form">
                <div className="container-fluid mt-3">
                    <div className="card card-body w-75 m-auto mt-5">
                        <div className="container-fluid mt-3">
                            <h2 className="text-center">Update Year Master</h2>
                            <form className="text-center">
                                <div className="mb-3 mt-3 ">
                                    <label htmlFor="year" className="m-2">Year</label>
                                    <input type="text" className="form-control w-50 m-auto" placeholder="Enter Year" onChange={handleUpdateYear} value={yearData} ></input>
                                    <button type="submit" className="btn btn-primary mt-4" onClick={handleSubmit} >Update year</button></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}