import React, { useState, useEffect } from 'react';
import axios from "axios";
import { apiUrl } from "../core/ApiConfig";
import { Link } from 'react-router-dom';

export default function GetUsers() {

   const [data, setData] = useState([]);
   const [tableData, setTableData] = useState([]);
   const [searchTerm, setSearchTerm] = useState('');

   var userData = [];

   const getData = () => {
      return fetch(apiUrl() + '/get-users-list')
         .then((res) => res.json())
         .then((d) => {
            if (d.statusCode == "200") {
               setData(...data, d.userData);
               setTableData(...data, d.userData);
            }
         })
   }

   useEffect(() => {
      getData();
   }, []);



   const handleSearch = (event) => {
      const term = event.target.value;
      setSearchTerm(term);

      if (term === '') {
         setData(tableData);

      } else {
         const filteredData = data.filter((row) =>
            Object.values(row).some((value) =>
               String(value).toLowerCase().includes(term.toLowerCase())
            )
         );
         setData(filteredData);
      }
   };

   return (
      <>
         <div className="container-fluid mt-3">
            <div className="card card-body">
               <h3 className="text-center m-4">CANDIDATE DETAILS</h3>
               <form className="row m-2 mb-3 ">
                  <div className="col-sm-11">
                     <input className="form-control"
                        type="text"
                        placeholder="Search..."
                        value={searchTerm}
                        onChange={handleSearch}
                     />
                  </div>
               </form>
               <div className='m-4'>
                  <table className="table-responsive-sm table  table-bordered text-center ">

                     <thead>
                        <tr>
                           <th className="table-dark">Candidate Id</th>
                           <th className="table-dark">Full Name</th>
                           <th className="table-dark">Email</th>
                           <th className="table-dark">Date Of Birth</th>
                           <th className="table-dark">View More Info</th>
                        </tr>
                     </thead>
                     <tbody>

                        {data ? (data.map((dataObj) => (
                           <tr key={dataObj.user_id}>
                              <td>{dataObj.user_id}</td>
                              <td>{dataObj.user_name}</td>
                              <td>{dataObj.email}</td>
                              <td>{dataObj.dob}</td>

                              <td>
                                 <Link to={`/userDetail/${dataObj.user_id}`} > <button className="btn btn-success">View More info</button></Link>
                              </td>
                           </tr>
                        ))) : <></>}
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </>
   )
}