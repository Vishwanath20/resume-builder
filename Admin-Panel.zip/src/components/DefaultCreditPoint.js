import { useEffect, useState } from 'react';
import axios from "axios";
import { apiUrl } from "../core/ApiConfig";

export default function DefaultCreditPoint() {
    // States for checking the errors
    const [submitted, setSubmitted] = useState(false);
    const [error, setError] = useState(false);
    const [defaultCreditPoint, setDefaultCreditPoint] = useState('');
    const [deductCreditPoint, setDeductCreditPoint] = useState('');

    // Showing success message
    const successMessage = () => {
        // return (
        //   <div
        //     className="success"
        //     style={{
        //       display: submitted ? '' : 'none',
        //     }}>
        //     <h1>User {name} successfully registered!!</h1>
        //   </div>
        // );
        if (submitted) {
            alert("Default credit point Added Successfully!!!");
            //  window.location.reload();
        }
    };

    // Showing error message if error is true
    const errorMessage = () => {
        return (
            <div
                className="error"
                style={{
                    display: error ? '' : 'none',
                }}>
                <h1>Please enter all the fields</h1>
            </div>
        );
    };

    const handleDefaultCreditPoints = (e) => {
        setDefaultCreditPoint(e.target.value);
        setSubmitted(false);
    };

    const handleCreditPointsDeduct = (e) => {
        setDeductCreditPoint(e.target.value);
        setSubmitted(false);
    };

    // Handling the form submission
    const handleSubmit = (e) => {
        e.preventDefault();
        if (defaultCreditPoint === '' || deductCreditPoint === '') {
            setError(true);
        } else {
            setSubmitted(true);
            setError(false);
            const formData = {
                defaultCreditPoint: defaultCreditPoint,
                deductCreditPoint: deductCreditPoint
            }

            postDefaultCreditPoints(formData);
        }
    };

    //post Data API Call
    const postDefaultCreditPoints = async (formData) => {

        try {
            const response = await axios.post(apiUrl() + '/post-default-credt-points', formData);

            if (response.data.statusCode == "200") {

                console.log(response.data.status)
            }
            else {
                console.log(response.data.status)
            }

        } catch (error) {
            console.error(error);
        }
    }

    return (

        <div className="card card-body w-75 m-auto mt-5">
            <h2 className="text-center m-4">Default Credit Point </h2>
            {/* Calling to the methods */}
            <div className="messages">
                {errorMessage()}
                {successMessage()}
            </div>

            <form className="text-center ">
                <div className="mb-3 mt-3">
                    <div className="row m-2">
                        <div className="col-sm-6 ">
                            <label htmlFor="" className="m-2">Default Credit Points Number </label>
                            <input type="text" className="form-control " id=""
                                placeholder="Enter default credit points" name="credit_points" onChange={handleDefaultCreditPoints}></input>
                        </div>
                        <div className="col-sm-6">
                            <label htmlFor="" className="m-2">Credit Points Deduct per Click</label>
                            <input type="text" className="form-control" id="" placeholder="Enter Credit Points Deduct per Click"
                                name="credit_points_deduct" onChange={handleCreditPointsDeduct}></input>
                        </div>
                    </div>
                    <button type="submit" className="btn btn-success mt-4" onClick={handleSubmit}>Submit</button>
                </div>
            </form>

        </div>
    )
}