import React, { useState, useEffect } from 'react';
import { Link, useParams } from "react-router-dom"
import { apiUrl } from "../core/ApiConfig";
import axios from "axios";

export default function UpdateTemplateMaster() {

    // Get the userId param from the URL.
    let { templateId } = useParams();

    // States
    const [templateName, setTemplateName] = useState('');
    const [templateImage, setTemplateImage] = useState('');
    const [templateType, setTemplateType] = useState([]);
    const [templateStatus, setTemplateStatus] = useState('');

    // const [templateData, setTemplateData] = useState([]);
    const [filePreview, setFilePreview] = useState("https://img.icons8.com/color/120/user.png");

    const [templateData, setTemplateData] = useState({ Name: '', image: '', status: '', type: '' });

    // States for checking the errors
    const [submitted, setSubmitted] = useState(false);
    const [error, setError] = useState(false);

    useEffect(() => {

        reflectTemplateMasterData(templateId)
    }, [])

    //Reflect-Template-MasterData Template Master Data API Call
    const reflectTemplateMasterData = async (templateID) => {

        try {

            const response = await axios.get(apiUrl() + `/get-template-master/${templateID}`);
            if (response.data.statusCode == "200") {
                const tempData = {
                    templateName: response.data.templateMasterData[0].name,
                    templateImage: response.data.templateMasterData[0].image,
                    templateType: response.data.templateMasterData[0].status,
                    templateStatus: response.data.templateMasterData[0].type

                }

                setTemplateData(tempData);

            }
            else {
                console.log(response.data.status)
            }

        } catch (error) {
            console.error(error);
        }
    }

    // Handling the package name change
    const handleTemplateName = (e) => {

        setTemplateName(e.target.value);
        setSubmitted(false);
    };

    // Handling the price change
    const handleTemplateImage = (e) => {
        const file = e.target.files[0];

        setTemplateImage(file);
        setSubmitted(false);
    };

    // Handling the Quantity change
    const handleTemplateType = (e) => {

        setTemplateType(e.target.value);
        setSubmitted(false);
    };

    // Handling the Total Amount change
    const handleTemplateStatus = (e) => {

        setTemplateStatus(e.target.value);
        setSubmitted(false);
    };
    // Handling the form submission
    const handleSubmit = (e) => {

        e.preventDefault();
        if (templateName === '' || templateImage === '' || templateType === '' || templateStatus === '') {
            setError(true);
        } else {
            setSubmitted(true);
            setError(false);

            let formData = new FormData();
            formData.append('templatePic', templateImage);
            formData.append('templateName', templateName);
            formData.append('templateType', templateType);
            formData.append('templateStatus', templateStatus);


            updatetTemplateMasterData(formData);
        }
    };

    const updatetTemplateMasterData = async (formData) => {

        try {

            const response = await axios.put(apiUrl() + `/update-template-master/${templateId}`, formData);


            if (response.data.statusCode == "200") {
                console.log(response.data.status)
            }
            else {
                console.log(response.data.status)
            }

        } catch (error) {
            console.error(error);
        }
    }

    // Showing success message
    const successMessage = () => {
        // return (
        //   <div
        //     className="success"
        //     style={{
        //       display: submitted ? '' : 'none',
        //     }}>
        //     <h1>User {name} successfully registered!!</h1>
        //   </div>
        // );
        if (submitted) {
            alert("Package Added Successfully!!!");
            // window.location.reload();
        }
    };

    // Showing error message if error is true
    const errorMessage = () => {
        return (
            <div
                className="error"
                style={{
                    display: error ? '' : 'none',
                }}>
                <h5 className='text-center text-danger'>Please enter all the fields</h5>
            </div>
        );
    };
    return (
        <>

            <div className="container-fluid mt-3">
                <div className="card card-body w-75 m-auto mt-5">

                    <h2 className="text-center m-4">Update template Master</h2>
                    {/* Calling to the methods */}
                    <div className="messages">
                        {errorMessage()}
                        {successMessage()}
                    </div>
                    <form className="text-center">
                        <div className="mb-3 mt-3">
                            <div className="row m-2">
                                <div className="col-sm-12">
                                    <label htmlFor="templateImage" className="templateImage" ><img style={{ height: "150px", width: "150px" }} src={filePreview} /> </label>
                                    <input className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base resize-none overflow-hidden"
                                        type="file" name="photo" onChange={handleTemplateImage} id="templateImage" style={{ display: "none" }} />
                                </div>
                            </div>
                            <div className="row m-2">
                                <div className="col-sm-12">
                                    <label htmlFor="year" className="m-2">Template Name</label>
                                    <input type="text" className="form-control" id="pkg_name"
                                        placeholder="Enter Template" name="template_name" defaultValue={templateData.templateName || ''} onChange={handleTemplateName}></input>
                                </div>

                            </div>
                            <div className="row m-2">

                                <div className="col-sm-6">
                                    <label htmlFor="year" className="m-2">Template Status</label>
                                    <input type="text" className="form-control " id="pkg_name" placeholder="Enter Amount"
                                        name="pkg_name" defaultValue={templateData.templateStatus || ''} onChange={handleTemplateStatus}></input>
                                </div>
                                <div className="col-sm-6">
                                    <label htmlFor="year" className="m-2">Template Type</label>
                                    <input type="text" className="form-control " id="pkg_name" placeholder="Template Type"
                                        name="Template_Type" defaultValue={templateData.templateType || ''} onChange={handleTemplateType}></input>
                                </div>
                            </div>

                            <button type="submit" className="btn btn-primary mt-4" onClick={handleSubmit}>Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </>
    )
}