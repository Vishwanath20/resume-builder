import { useEffect, useState } from 'react';
import axios from "axios";
import { apiUrl } from "../core/ApiConfig";

export default function Adduser() {
    // States for checking the errors
    const [submitted, setSubmitted] = useState(false);
    const [error, setError] = useState(false);
    const [name, setName] = useState('');
    const [email, setDefaultCreditPoint] = useState('');
    const [password, setDeductCreditPoint] = useState('');
    const [adminType, setAdmintype] = useState('');
 
   const errorMessage = () => {
        return (
            <div
                className="error"
                style={{
                    display: error ? '' : 'none',
                }}>
                <h1>Please enter all the fields</h1>
            </div>
        );
    };

    const handleDefaultCreditPoints = (e) => {
        setDefaultCreditPoint(e.target.value);
        setSubmitted(false);
    };

    const handleCreditPointsDeduct = (e) => {
        setDeductCreditPoint(e.target.value);
        setSubmitted(false);
    };
    const handlesetName = (e) => {
        setName(e.target.value);
        setSubmitted(false);
    };
    const handlesetadmintype = (e) => {
        setAdmintype(e.target.value);
        setSubmitted(false);
    };
    // Handling the form submission
    const handleSubmit = (e) => {
        e.preventDefault();
        if (email === '' || password === '') {
            setError(true);
        } else {
            setSubmitted(true);
            setError(false);
            const formData = {
                name,
                email,
                adminType,
                password
            }
          
            postDefaultCreditPoints(formData);
        }
    };

    //post Data API Call
    const postDefaultCreditPoints = async (formData) => {
     
        try {
            const response = await axios.post(apiUrl() + '/post-admin-user', formData);
        
            if (response.data.statusCode == "200") {
                alert(response.data.status)
            }
            else {
                alert(response.data.status)
            }

        } catch (error) {
            console.error(error);
        }
    }

    return (

        <div className="card card-body w-75 m-auto mt-5">
            <h2 className="text-center m-4">Add User </h2>
            {/* Calling to the methods */}
            <div className="messages">
                {errorMessage()}
            </div>

            <form>
                <div className="mb-3 mt-3">
                    <div className="row m-2">
                    <div className="col-sm-12 ">
                            <label htmlFor="" className="m-2">Name</label>
                            <input type="text" className="form-control " id=""
                                placeholder="Enter Name" name="credit_points" onChange={handlesetName}></input>
                        </div>
                        <div className="col-sm-12 ">
                            <label htmlFor="" className="m-2">Email </label>
                            <input type="text" className="form-control " id=""
                                placeholder="Enter Email" name="credit_points" onChange={handleDefaultCreditPoints}></input>
                        </div>
                        <div className="col-sm-12">
                            <label htmlFor="" className="m-2">Password</label>
                            <input type="text" className="form-control" id="" placeholder="Enter Password"
                                name="credit_points_deduct" onChange={handleCreditPointsDeduct}></input>
                        </div>
                        <div className="col-sm-12">
                            <label htmlFor="" className="m-2">Admin Type</label>
                            <select type="text" className="form-control"onChange={handlesetadmintype}>
                                <option>Select</option>
                                <option value={1}>Super Admin</option>
                                <option value={2}>Admin</option>
                            </select>
                        </div>
                        <div className="col-sm-12 mt-3">
                         <button type="submit" className="btn btn-success mt-4 form-control" onClick={handleSubmit}>Submit</button>
                        </div>
                    </div>
                   
                </div>
            </form>

        </div>
    )
}