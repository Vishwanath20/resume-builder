import { useEffect, useState } from 'react';
import axios from "axios";
import { apiUrl } from "../core/ApiConfig";
import { Link } from "react-router-dom"

export default function YearMaster() {

  // States for registration
  const [year, setYear] = useState('');
  const [yearData, setYearData] = useState([]);

  // States for checking the errors
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(false);

  // Handling the name change
  const handleYear = (e) => {
    setYear(e.target.value);
    setSubmitted(false);
  };

  // Handling the form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (year === '') {
      setError(true);
    } else {
      setSubmitted(true);
      setError(false);

      postYear(year);
    }
  };

  // Showing success message
  const successMessage = () => {
    // return (
    // <div
    //   className="success"
    //   style={{
    //     display: submitted ? '' : 'none',
    //     color: 'blue',
    //   }}>
    //   <h4>Year {year} successfully registered!!</h4>
    // </div>
    if (submitted) {
      alert("Year Added Successfully!!!");
    }
    // );
  };

  // Showing error message if error is true
  const errorMessage = () => {
    if (error) {
      alert("Please enter value for Year field!!!");
    }
  };

  const postYear = async (year) => {

    try {
      const response = await axios.post(apiUrl() + '/post-year-master', {
        year: year
      });

      if (response.data.statusCode == "200") {
        console.log(response.data.status)
      }
      else {
        console.log(response.data.status)
      }

    } catch (error) {
      console.error(error);
    }
  }

  const getYearMasterList = async () => {

    try {
      const response = await axios.get(apiUrl() + '/get-year-master');

      if (response.data.statusCode == "200") {

        setYearData(...yearData, response.data.yearData);

      }
      else {
        console.log(response.data.status)
      }

    } catch (error) {
      console.error(error);
    }
  }



  useEffect(() => {
    getYearMasterList()
  }, [])




  const deleteYear = async (yearid) => {

    try {
      const response = await axios.get(apiUrl() + `/delete-year-master/${yearid}`);

      if (response.data.statusCode == "200") {


        window.location.reload();

      }
      else {
        console.log(response.data.status)
      }

    } catch (error) {
      console.error(error);
    }
  }

  return (
    <div className="form">

      <div className="messages">
        {errorMessage()}
        {successMessage()}
      </div>

      <div className="container-fluid mt-3">
        <div className="card card-body w-50 m-auto mt-5">
          <h2 className="text-center m-4">Year Master</h2>
          <form className="text-center">
            <div className="mb-3 mt-3 ">
              <label htmlFor="year" className="m-2">Year</label>
              <input type="text" className="form-control w-50 m-auto" placeholder="Enter Year" onChange={handleYear} value={year} ></input>
              <button type="submit" onClick={handleSubmit} className="btn btn-success mt-4">Add</button></div>
          </form>
        </div>
      </div>

      <div className='mt-5 mb-5'>
        <div className="card card-body w-50 m-auto mt-5">
          <h3 className="text-center m-4">Registered Years</h3>
          <div className="table-responsive">
            <table className="table table-hover table-bordered text-center">
              <thead>
                <tr>
                  <th>Year</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>



                {yearData ? (
                  yearData.map((dataObj, index) => (

                    <tr key={dataObj.int_year_id}>
                      <td>{dataObj.year}</td>
                      <td>
                        <Link to={`/updateYearMaster/${dataObj.int_year_id}`} > <button className="btn btn-primary mr-3">Update</button></Link>
                        <></>
                        <button className="btn btn-danger" onClick={() => deleteYear(`${dataObj.int_year_id}`)}>Delete</button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <p></p>
                )}


              </tbody>

              {/* <tbody>
                  <tr>
                    <td>1979</td>
                    <td><button className="btn btn-success">Update</button></td>
                  </tr>
                  <tr>
                    <td>1980</td>
                    <td><button className="btn btn-success">Update</button></td>
                  </tr>

                  <tr>
                    <td>1981</td>
                    <td><button className="btn btn-success">Update</button></td>
                  </tr>
                </tbody> */}
            </table>
          </div>

        </div>
      </div>


    </div>
  );
}