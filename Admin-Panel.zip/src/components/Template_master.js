import { useEffect, useState } from 'react';
import axios from "axios";
import { apiUrl } from "../core/ApiConfig";
import { Link } from "react-router-dom"

export default function TemplateMaster() {

  useEffect(() => {
    getpackageList()
    getTemplateMasterData()
  }, [])

  let apiURL = apiUrl();
  // States
  const [templateName, setTemplateName] = useState('');
  const [templateImage, setTemplateImage] = useState('');
  const [templateType, setTemplateType] = useState([]);
  const [templateStatus, setTemplateStatus] = useState('');
  const [templateNum, setTemplatenum] = useState('');
  const [underPackage, setUnderpackage] = useState('');
  const [packageName, setpackageName] = useState('');
  const [templateData, setTemplateData] = useState([]);
  const [filePreview, setFilePreview] = useState("https://img.icons8.com/color/150/add-image.png");
  // Handling the form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (templateName === '' || templateImage === '' || templateType === '' || templateStatus === '') {
      setError(true);
    } else {
      setSubmitted(true);
      setError(false);
      let formData = new FormData();
      formData.append('templatePic', templateImage);
      formData.append('templateNum', templateNum);
      formData.append('underPackage', underPackage);
      formData.append('templateName', templateName);
      formData.append('templateType', templateType);
      formData.append('templateStatus', templateStatus);

      postTemplateMasterData(formData);
    }
  };

  // States for checking the errors
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(false);

  // Handling the package name change
  const handleTemplateName = (e) => {
    setTemplateName(e.target.value);
    setSubmitted(false);
  };

  // Handling the price change
  const handleTemplateImage = (e) => {
    const file = e.target.files[0];
    setTemplateImage(file);
    setSubmitted(false);
  };

  // Handling the Quantity change
  const handleTemplateType = (e) => {
    setTemplateType(e.target.value);
    setSubmitted(false);
  };
  const handleTemplateNum = (e) => {
    setTemplatenum(e.target.value);
    setSubmitted(false);
  };
  const handleunderPackage = (e) => {

    setUnderpackage(e.target.value);
    setSubmitted(false);
  };
  const handleTemplateStatus = (e) => {
    setTemplateStatus(e.target.value);
    setSubmitted(false);
  };

  //post Data API Call
  const postTemplateMasterData = async (formData) => {
    try {
      const response = await axios.post(apiUrl() + '/post-template-master', formData);

      if (response.data.statusCode == "200") {
        console.log(response.data.status)
      }
      else {
        console.log(response.data.status)
      }

    } catch (error) {
      console.error(error);
    }
  }

  //DELETE Template Master Data API Call
  const deletePackageMasterData = async (templateId) => {
    try {
      const response = await axios.get(apiUrl() + `/delete-template-master/${templateId}`);
      if (response.data.statusCode == "200") {
        window.location.reload();
      }
      else {
        console.log(response.data.status)
      }
    } catch (error) {
      console.error(error);
    }
  }

  // Showing success message
  const successMessage = () => {
    // return (
    //   <div
    //     className="success"
    //     style={{
    //       display: submitted ? '' : 'none',
    //     }}>
    //     <h1>User {name} successfully registered!!</h1>
    //   </div>
    // );
    if (submitted) {
      alert("Template Added Successfully!!!");
    }
  };

  // Showing error message if error is true
  const errorMessage = () => {
    return (
      <div
        className="error"
        style={{
          display: error ? '' : 'none',
        }}>
        <h5 className='text-center text-danger'>Please enter all the fields</h5>
      </div>
    );
  };

  //GET Template Master Data API Call
  const getTemplateMasterData = async () => {
    try {
      const response = await axios.get(apiUrl() + '/get-template-master');
      if (response.data.statusCode == "200") {
        setTemplateData(...templateData, response.data.templateMasterData);
        console.log(response.data.status)
      }
      else {
        console.log(response.data.status)
      }

    } catch (error) {
      console.error(error);
    }
  }
  const getpackageList = async () => {
    try {
      const response = await axios.get(apiUrl() + '/get-package-name');
      if (response.data.statusCode == "200") {
        const options = response.data.result.map((item) => {
          return (
            <option value={item.package_list_id}>{item.package_name}</option>
          )
        });
        setpackageName(options)
      }
      else {
        console.log(response.data.status)
      }

    } catch (error) {
      console.error(error);
    }
  }
  return (
    <>
      <div className="container-fluid mt-3">
        <div className="card card-body w-50 m-auto mt-5">
          <h2 className="text-center ">Template Master</h2>
          {/* Calling to the methods */}
          <div className="messages">
            {errorMessage()}
            {successMessage()}
          </div>
          <form className="text-center">
            <div className="mb-3 mt-3">
              <div className='row'>
                <div className="form-group col-sm-12  mt-2">
                  <label htmlFor="templateImage" className="templateImage" >
                    <img style={{ height: "150px", width: "150px" }} src={filePreview} />
                  </label>
                  <input className="mt-1 px-3 py-2 block w-full rounded-md border border-gray-300 text-gray-900 shadow-sm outline-none font-normal text-base resize-none overflow-hidden"
                    type="file" name="photo" onChange={handleTemplateImage} id="templateImage" style={{ display: "none" }} />
                </div>
              </div>
              <div className="row m-2">
                <div className="col-sm-12">
                  <label htmlFor="year" className="m-2">Template Name</label>
                  <input type="text" className="form-control " id="pkg_name"
                    placeholder="Enter Template Name" name="pkg_name" onChange={handleTemplateName}></input>
                </div>

              </div>
              <div className="row m-2">
                <div className="col-sm-6">
                  <label htmlFor="year" className="m-2">Template Number</label>
                  <input type="text" className="form-control " id="pkg_name" placeholder="Enter template number"
                    name="pkg_name" onChange={handleTemplateNum}></input>
                </div>
                <div className="col-sm-6">
                  <label htmlFor="year" className="m-2">Select under package</label>
                  <select type="text" className="form-control " id="pkg_name" placeholder="Enter Status"
                    name="pkg_name" onChange={handleunderPackage}>
                    <option>Select</option>
                    {packageName}
                  </select>
                </div>
              </div>
              <div className="row m-2">
                <div className="col-sm-6">
                  <label htmlFor="year" className="m-2">Type</label>
                  <select type="text" className="form-control " id="pkg_name" placeholder="Enter Type"
                    name="pkg_name" onChange={handleTemplateType}>
                    <option>Select</option>
                    <option value={0}>Free</option>
                    <option value={1}>Paid</option>
                  </select>
                </div>
                <div className="col-sm-6">
                  <label htmlFor="year" className="m-2">Status</label>
                  <select type="text" className="form-control " id="pkg_name" placeholder="Enter Status"
                    name="pkg_name" onChange={handleTemplateStatus}>
                    <option>Select status</option>
                    <option>Un Active</option>
                    <option>Active</option>
                  </select>
                </div>
              </div>

              <button type="submit" className="btn btn-success mt-4" onClick={handleSubmit}>Submit</button>
            </div>
          </form>
        </div>

        <div className='mt-5 mb-5'>
          <div className="card card-body">
            <h3 className="text-center m-4">Registered Template</h3>
            <div className="table-responsive">
              <table className="table table-hover table-bordered text-center">
                <thead>
                  <tr>
                    <th>Sr. No.</th>
                    <th>Template ID</th>
                    <th>Template Name</th>
                    <th>Template Image</th>
                    <th>Template Status</th>
                    <th>Template Type</th>
                    <th>Update</th>
                    <th>Delete</th>
                  </tr>
                </thead>
                <tbody>

                  {templateData ? (
                    templateData.map((dataObj, index) => (

                      <tr key={dataObj.template_id}>
                        <td>{index + 1}</td>
                        <td>{dataObj.template_id}</td>
                        <td>{dataObj.name}</td>
                        {/* <td>{dataObj.image}</td> */}
                        <td>
                          <img style={{ height: "100px", width: "100px" }} src={`${apiURL}${dataObj.image}`} />
                        </td>
                        <td>{dataObj.status}</td>
                        <td>{dataObj.type}</td>
                        <td>
                          <Link to={`/UpdateTemplateMaster/${dataObj.template_id}`} > <button className="btn btn-primary mr-3">Update</button></Link>
                        </td>
                        <td>
                          <button className="btn btn-danger" onClick={() => deletePackageMasterData(`${dataObj.template_id}`)}>Delete</button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <p></p>
                  )}


                </tbody>
              </table>
            </div>

          </div>
        </div>


      </div>
    </>
  )
}