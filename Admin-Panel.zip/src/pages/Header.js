import { useState, useEffect } from "react";
import Cookies from "js-cookie";
import { jwtDecode } from "jwt-decode";
import { useNavigate } from "react-router-dom";
export default function Header() {
   const [jwt, setJwt] = useState({});
   const navigate = useNavigate();

   useEffect(() => {
      let cookie = Cookies.get('adminUser')
      if (cookie != undefined) {
         let decode = jwtDecode(Cookies.get('adminUser'))
         setJwt(decode)
      }
      else {
         navigate(`/Login`, { replace: true });
      }
   }, [])
   const logOut = () => {
      Cookies.remove('adminUser');
      window.location.reload();
   }
   return (
      <>
         <header id="header" className="header">
            <div className="top-left">
               <div className="navbar-header">
                  <a className="navbar-brand" href="index.html"><img src="images/logo.png" alt="Logo" /></a>
                  {/* <a className="navbar-brand hidden" href="index.html"><img src="images/logo2.png" alt="Logo"/></a> */}
                  <a id="menuToggle" className="menutoggle"><i className="fa fa-solid fa-bars"></i></a>
               </div>
            </div>
            <div className="top-right">
               <div className="header-menu">
                  <div className="user-area dropdown float-right">

                     <a href="#" className="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i className="fa fa-user-circle-o"></i></a>
                     <div className="user-menu dropdown-menu">
                        <a>Welcome {jwt.name}</a>
                        <a onClick={logOut} className="nav-link" href="#"><i className="fa fa-power-off"></i>Logout</a>
                     </div>
                  </div>
               </div>
            </div>
         </header>
      </>
   )
}