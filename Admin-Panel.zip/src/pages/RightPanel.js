import Header from "./Header";
import Footer from "./Footer";
import ContentArea from "./ContentArea";

export default function RightPanel(){
    return(
        <>
       <div id="right-panel" className="right-panel">
        
         <Header></Header>
         <ContentArea></ContentArea>
         {/* <div className="clearfix"></div> */}
        <Footer></Footer>
      </div>
        </>
    )
}