
import { Route, Routes } from 'react-router-dom';
import GetUsers from '../components/GetUsers';
import YearMaster from '../components/Year_Master';
import Cookies from 'js-cookie';
import UserDetail from '../components/UserDetail';
import UpdateYearMaster from '../components/UpdateYearMaster';
import UpdatePackageMaster from '../components/UpdatePackageMaster';
import PackageMaster from '../components/Package_master';
import TemplateMaster from '../components/Template_master';
import UpdateTemplateMaster from '../components/UpdateTemplateMaster';
import DefaultCreditPoint from '../components/DefaultCreditPoint';
import Adduser from '../components/Adduser';
import LoginPage from './Login';

export default function ContentArea() {
   return (
      <>


         <div className="content pb-0">
            <div className="orders">
               <Routes>
                  <Route path="/" exact element={Cookies.get('adminUser') != undefined ? <GetUsers /> : <LoginPage />} />
                  <Route path='/year_master' exact element={Cookies.get('adminUser') != undefined ? <YearMaster /> : <LoginPage />} />
                  <Route path='/package_master' exact element={Cookies.get('adminUser') != undefined ? <PackageMaster></PackageMaster> : <LoginPage />}></Route>
                  <Route path='/userDetail/:uid' exact element={Cookies.get('adminUser') != undefined ? <UserDetail /> : <LoginPage />} />
                  <Route path='/updateYearMaster/:yearid' exact element={Cookies.get('adminUser') != undefined ? <UpdateYearMaster /> : <LoginPage />} />
                  <Route path='/UpdatePackageMaster/:packageId' exact element={Cookies.get('adminUser') != undefined ? <UpdatePackageMaster /> : <LoginPage />} />
                  <Route path='/template_master' exact element={Cookies.get('adminUser') != undefined ? <TemplateMaster /> : <LoginPage />} />
                  <Route path='/UpdateTemplateMaster/:templateId' exact element={Cookies.get('adminUser') != undefined ? <UpdateTemplateMaster /> : <LoginPage />} />
                  <Route path='/defaultCreditPoints' exact element={Cookies.get('adminUser') != undefined ? <DefaultCreditPoint /> : <LoginPage />} />
                  <Route path='/Adduser' exact element={Cookies.get('adminUser') != undefined ? <Adduser /> : <LoginPage />} />
                  <Route path='/Login' exact element={<LoginPage />} />
               </Routes>
            </div>
         </div>
      </>
   )
}