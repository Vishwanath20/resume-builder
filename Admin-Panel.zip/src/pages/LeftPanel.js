import { Link } from "react-router-dom";
export default function LeftPanel() {
   return (
      <>
         <aside id="left-panel" className="left-panel">
            <nav className="navbar navbar-expand-sm navbar-default">
               <div id="main-menu" className="main-menu collapse navbar-collapse">
                  <ul className="nav navbar-nav">
                     <li className="menu-title">Menu</li>
                     <li className="menu-item-has-children dropdown">
                        <Link to="/">DashBoard</Link>
                     </li>
                     <li className="menu-item-has-children dropdown">
                        <Link to="/year_master"> Year Master</Link>
                     </li>
                     <li className="menu-item-has-children dropdown">
                        <Link to="/package_master" >Package Master</Link>
                     </li>
                     <li className="menu-item-has-children dropdown">
                        <Link to="/template_master" >Template Master</Link>
                     </li>
                     <li className="menu-item-has-children dropdown">
                        <Link to="/defaultCreditPoints" >Default Credit Points Setting</Link>
                     </li>
                     <li className="menu-item-has-children dropdown">
                        <Link to="/Adduser" >Add Sub Admin</Link>
                     </li>


                  </ul>
               </div>
            </nav>
         </aside>
      </>
   )
}