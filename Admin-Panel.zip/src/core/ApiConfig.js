
const apiUrl = () => {
    //  return "http://localhost:4000";
    return "https://api.magicpoint.in";

}


export {
    apiUrl
}
