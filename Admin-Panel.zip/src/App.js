import logo from './logo.svg';
import './App.css';
import { Helmet } from 'react-helmet';
import LeftPanel from './pages/LeftPanel';
import RightPanel from './pages/RightPanel';
import Cookies from 'js-cookie';

function App() {
  return (
    <>

      <div>
        {Cookies.get('adminUser') != undefined ? <LeftPanel /> : ''}
        <RightPanel />
      </div>

      < Helmet>

        <script src="assets/js/main.js"></script>
        {/* <script src="/public/assets/js/main.js"></script> */}

      </Helmet>
    </>
  );
}

export default App;
